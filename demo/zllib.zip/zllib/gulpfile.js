var gulp = require('gulp');
var concat = require('gulp-concat');
var minifyCss = require('gulp-minify-css');
var rename = require('gulp-rename');
// var sh = require('shelljs');

//====================================================

var templateCache = require('gulp-angular-templatecache');
var useref = require('gulp-useref');
var minifyHTML = require("gulp-minify-html");
var htmlreplace = require('gulp-html-replace');
var ngAnnotate = require('gulp-ng-annotate');
var gulpif = require('gulp-if');
var uglify = require('gulp-uglify');
var imagemin = require('gulp-imagemin');
var del = require('del');
var removeCode = require('gulp-remove-code');
var jsoncombine = require('gulp-jsoncombine');
var wrap = require('gulp-wrap');
var template = require('gulp-template');
var data = require('gulp-data');
var htmlhint = require("gulp-htmlhint");
var jshint = require('gulp-jshint');
var rev = require('gulp-rev');
var revReplace = require('gulp-rev-replace');
var filter = require('gulp-filter');

var javascriptObfuscator = require('gulp-javascript-obfuscator');
var merge2 = require('merge2');
//====================================================

var flag = true;

//清空≥
gulp.task("0del", function () {
    console.info("=====>    清空源构建目录 ");
    return del(['./dist']);
});

gulp.task('test', function (done) {
    gulp.src('./www/**/*.js')
        .pipe(javascriptObfuscator({
            compact:true,
            disableConsoleOutput: false,
            sourceMap: false
        }))
        .pipe(gulp.dest('./test'))
        .on('end', done);
});

//压缩css
gulp.task('1minStyleCss', function (done) {
    gulp.src('./www/**/style.css')
        .pipe(gulpif('*.css', minifyCss()))
        .pipe(rename({ extname: '.min.css' }))
        .pipe(gulp.dest('./dist'))
        .on('end', done);
});

gulp.task('1_ngAnnotate', function (done) {
    gulp.src('./www/**/*.js')
        .pipe(ngAnnotate({single_quotes: true}))
        .pipe(gulp.dest('./dist'))
        .on('end', done);
});

gulp.task('1removeCode_index', function (done) {
    gulp.src('./www/**/index.html')
        .pipe(removeCode({ zzdebug: true , zz_wx: true ,zztest:flag }))
        .pipe(gulp.dest('./dist'))
        .on('end', done);
});

gulp.task('1removeCode_utils', function (done) {
    gulp.src('./www/js/**/*.js')
        .pipe(removeCode({ zzdebug: true , zz_wx: true , noCookie:true,zztest:flag }))
        .pipe(gulp.dest('./dist'))
        .on('end', done);
});

gulp.task('1_wx_index_lib_css', function (done) {
    gulp.src('./www/**/*.html')
        .pipe(removeCode({ zzdebug: true , zz_wx: true ,zztest:flag }))
        .pipe(useref())
        .pipe(gulpif('*.js', ngAnnotate({single_quotes: true})))
        .pipe(gulpif('*.js', uglify()))
        .pipe(gulpif('*.css', minifyCss()))
        .pipe(gulp.dest('./dist'))
        .on('end', done);
});

gulp.task('1_wx_html', function (done) {
    gulp.src('./www/**/*.html')
        .pipe(removeCode({ zzdebug: true , zz_wx: true ,zztest:flag }))
        .pipe(htmlhint({
            "title-require": false,
            "doctype-first": false,
            "attr-lowercase": false,
        }))
        .pipe(htmlhint.reporter())
        .pipe(htmlhint.failReporter())
        .pipe(gulp.dest('./dist'))
        .on('end', done);
});

gulp.task("1_wx_deal_appjs", function () {
    return gulp.src("./www/lib/base/app.js")
        .pipe(jshint())
        .pipe(jshint.reporter('default'))
        .pipe(removeCode({ zzdebug: true , zz_wx: true , noCookie:true,zztest:flag }))
        .pipe(gulpif('*.js', ngAnnotate({single_quotes: true})))
        .pipe(gulpif('*.js', javascriptObfuscator({
            compact:true,
            disableConsoleOutput: false,
            sourceMap: false
        })))
        .pipe(gulpif('*.js', uglify()))
        .pipe(gulp.dest('./dist/lib/base/'));
});

gulp.task('1_wx_deal_utils_bak', function (done) {
    del(['./dist/lib/base/util']);

    gulp.src([
            './www/lib/base/base64.min.js',
            './www/lib/ocLazyLoad/ocLazyLoad.min.js',
            './www/lib/base/util/interceptor/auth.js',
            './www/lib/base/util/cookie/cookie.js',
            './www/lib/base/app.js',
            './www/lib/base/util/uuid/uuid.js',
            './www/lib/base/util/math/math.js',
            './www/lib/base/util/locals/locals.js',
            './www/lib/base/util/date/date.js',
            './www/lib/base/util/http/http.js',
            './www/lib/base/utils.js'
        ])
        .pipe(concat('utils.js'))
        // .pipe(removeCode({ zzdebug: true , zz_wx: true , noCookie:true}))
        .pipe(gulpif('*.js', ngAnnotate({single_quotes: true})))
        .pipe(gulpif('*.js', javascriptObfuscator({
            compact:true,
            disableConsoleOutput: false,
            sourceMap: false
        })))
        .pipe(gulpif('*.js', uglify()))
        .pipe(gulp.dest('./dist/lib/base/'))
        .on('end', done);
});

gulp.task('1_wx_deal_utils', function (done) {
    del(['./dist/lib/base/util']);

    var streamUtils = gulp.src([
        // './www/lib/base/base64.min.js',
        './www/lib/ocLazyLoad/ocLazyLoad.min.js',
        './www/lib/base/util/interceptor/auth.js',
        './www/lib/base/util/cookie/cookie.js',
        './www/lib/base/app.js',
        './www/lib/base/util/uuid/uuid.js',
        './www/lib/base/util/math/math.js',
        './www/lib/base/util/locals/locals.js',
        './www/lib/base/util/date/date.js',
        './www/lib/base/util/http/http.js',
        './www/lib/base/utils.js'
    ])
        .pipe(concat('utils.js'))
        // .pipe(removeCode({ zzdebug: true , zz_wx: true , noCookie:true}))
        .pipe(gulpif('*.js', ngAnnotate({single_quotes: true})))
        .pipe(gulpif('*.js', javascriptObfuscator({
            compact:true,
            disableConsoleOutput: false,
            sourceMap: false
        })));
    // .pipe(gulpif('*.js', uglify()));
    // .pipe(gulp.dest('./dist/lib/base/'));

    var streamEvents = gulp.src([
        './www/lib/base/util/security/des.js',
        // './www/lib/base/base64.min.js'
    ]);
    // .pipe(concat('test.js'))
    // .pipe(gulpif('*.js', uglify()));
    // .pipe(gulp.dest('./dist/lib/base/'));

    merge2(streamUtils, streamEvents)
        .pipe(concat('utils.js'))
        .pipe(gulpif('*.js', uglify()))
        .pipe(gulp.dest('./dist/lib/base/'))
        .on('end', done);
});

gulp.task('1_wx_default_conf_utils', function (done) {

     gulp.src([
            './www/lib/base/util/http/httpConf.js'
        ])
        .pipe(gulpif('*.js', ngAnnotate({single_quotes: true})))
        .pipe(gulpif('*.js', uglify()))
        .pipe(gulp.dest('./tmp/'))
        .on('end', done);
});

gulp.task('1_wx_default_conf_appjs',['1_wx_default_conf_utils'], function (done) {

    gulp.src([
            './dist/lib/base/app.js',
            './tmp/httpConf.js'
        ])
        .pipe(concat('app.js'))
        .pipe(gulp.dest('./dist/lib/base/'))
        .on('end', done);
});

gulp.task('1_wx_deal_app_dir', function (done) {
    del(['./dist/app']);

    gulp.src("./www/app/**/*.*")
        .pipe(removeCode({ zzdebug: true , zz_wx: true , noCookie:true,zztest:true }))
        .pipe(gulpif('*.js', ngAnnotate({single_quotes: true})))
        .pipe(gulp.dest('./dist/app/'))
        .on('end', done);
});

gulp.task("1_wx_copy_resource", function () {
    gulp.src("./www/img/**/*.*")
        .pipe(gulpif('*.*(jpg|png)', imagemin()))
        .pipe(gulp.dest('./dist/img/'));
    gulp.src("./www/css/main.css")
        .pipe(gulp.dest('./dist/css/'));
    gulp.src("./www/lib/ionic/fonts/**/*.*")
        .pipe(gulp.dest('./dist/lib/ionic/fonts/'));
    gulp.src("./www/lib/zz/img/**/*.*")
        .pipe(gulpif('*.*(jpg|png)', imagemin()))
        .pipe(gulp.dest('./dist/lib/ionic/img/'));
    gulp.src("./www/aslib/**/*.*")
        .pipe(gulp.dest('./dist/aslib/'));
});

gulp.task('1_html_check', function (done) {
    gulp.src('./app/**/*.html')
        .pipe(htmlhint({
            "title-require": false,
            "doctype-first": false,
            "attr-lowercase": false,
            "attr-no-duplication": false,
        }))
        .pipe(htmlhint.reporter())
        .pipe(htmlhint.failReporter())
        .on('end', done);
});

gulp.task("1_js_check", function () {
    return gulp.src(["./app/**/*.js",'!./app/base/lib/**/*.*'])
        .pipe(jshint())
        .pipe(jshint.reporter('default'))
});

gulp.task('1_wx_default_real', ['1_wx_index_lib_css','1_wx_deal_utils','1_wx_deal_app_dir','1_wx_copy_resource'],function () {
});

gulp.task('1_wx_default_***', ['0del'],function () {
    gulp.start('1_wx_default_real');
});

gulp.task('1_wx_default_***_del', function () {
    return del(['./dist/app/demo','./tmp','./dist/app/zouke']);
});

gulp.task('1_default0_del', function () {
    return del(['./0dist/']);
});

gulp.task("0index_md5", ['1_default0_del'], function () {
    var jsFilter = filter("**/*.js", {restore: true});
    var cssFilter = filter("**/*.css", {restore: true});
    var indexHtmlFilter = filter(['**/*', '!**/index.html', '!**/app/base/lib/**/*', '!**/img/**/*', '!**/ionic/**/*'], {restore: true});

    return gulp.src("**/*")
        .pipe(jsFilter)
        .pipe(jsFilter.restore)
        .pipe(cssFilter)
        .pipe(cssFilter.restore)
        .pipe(indexHtmlFilter)
        .pipe(rev())                // Rename the concatenated files (but not index.html)
        .pipe(indexHtmlFilter.restore)
        .pipe(revReplace())         // Substitute in new filenames
        .pipe(gulp.dest('0dist'));
});
//====================================================

gulp.task('default1', ['h2t','db','imgmin','movelib'],function () {
  // return del(['./dist/html','./dist/js/**/*.html','./dist/lib/ng*/']);
  gulp.start('ojs2');
  return del(['./dist/html','./dist/js/**/*.html','./dist/lib/ng*/']);
});

/**
 * 模板替换
 */
gulp.task('tpl', function () {
    gulp.src('./www/greeting.html')
        .pipe(data(function () {
            return {name:'我是模板内容'};
        }))
        .pipe(template())
        .pipe(gulp.dest('dist'))
});

gulp.task('ojs2', function (done) {
  gulp.src('./www/**/controller1.js')
    .pipe(concat('./js/app1.js'))    //合并所有js到app1.js
    .pipe(gulpif('*.js', ngAnnotate({single_quotes: true})))
    .pipe(gulpif('*.js', uglify()))
    .pipe(gulp.dest('./dist'))
    .on('end', done);
  // return del(['./dist/html','./dist/js/**/*.html','./dist/lib/ng*/']);
});

gulp.task('default', ['del'],function () {
  gulp.start('default1');
});

gulp.task('json',function() {
  return gulp.src('./t/*.json')
    .pipe(jsoncombine('text.js', function(files) {
       return new Buffer(JSON.stringify(files, null, 2));
    })) //use .js extension since we plan to wrap
    .pipe(wrap('angular.module(\'text\', []).value(<%= contents %>);'))
    .pipe(gulp.dest("./dist"));
});

//html压缩替换
/**
 * <!-- build:js -->
 <script src="js/app.js"></script>
 <!-- endbuild -->
 */
gulp.task('htmlmini',function() {
  var opts = {comments:false,spare:false,quotes:true};
  return gulp.src('./www/html/**/*.html')
    .pipe(htmlreplace({
      'css': 'css/all.min.css',
      'js': 'js/all.min.js'
    }))
    .pipe(minifyHTML(opts))
    .pipe(gulp.dest('./dist/'));
});

// //html压缩替换
// gulp.task('htmlmini2js',function() {
//   var opts = {comments:false,spare:false,quotes:true};
//   return gulp.src('./www/html/**/*.html')
//     .pipe(htmlreplace({
//       'css': 'css/all.min.css',
//       'js': 'js/all.min.js'
//     }))
//     .pipe(minifyHTML(opts))
//     .pipe(templateCache({standalone:true}))
//     .pipe(gulp.dest('./dist/js'));
// });

//copy 保留全路径
gulp.task("copypath", function () {
  return gulp.src("./www/index.html", {base:"."})
    .pipe(gulp.dest('./dist'));
});

//copy
gulp.task("copyindex", function () {
  return gulp.src("./www/index.html")
    .pipe(gulp.dest('./dist'));
});

var baseFn = function (file) { return './' + file.relative; }

//html to js
//TODO: ...@_@... 模板压缩合并
gulp.task('h2t', function (done) {
  var opts = {comments:false,spare:false,quotes:true};

  gulp.src('./www/html/**/*.html')
    .pipe(htmlreplace({
      'css': 'css/all.min.css',
      'js': 'js/all.min.js'
    }))
    .pipe(minifyHTML(opts))
    // .pipe(templateCache({standalone:true}))
    .pipe(templateCache('templates.js', {root: 'html/', module:'zouke',base: baseFn}))
    .pipe(gulp.dest('./dist/js'))
    .on('end', done);
});

gulp.task('nga', function (done) {
  gulp.src('./www/js/*.js')
    .pipe(ngAnnotate({single_quotes: true}))
    .pipe(gulp.dest('./dist/js'))
    .on('end', done);
});

gulp.task('useref', function (done) {
  gulp.src('./www/**/*.html')
    .pipe(useref())
    .pipe(gulp.dest('./dist'))
    .on('end', done);
});

gulp.task('db', function (done) {
  gulp.src('./www/**/*.html')
    .pipe(removeCode({ zzdebug: true }))
    .pipe(useref())
    .pipe(gulpif('*.js', ngAnnotate({single_quotes: true})))
    .pipe(gulpif('*.js', uglify()))
    .pipe(gulpif('*.css', minifyCss()))
    .pipe(gulp.dest('./dist'))
    .on('end', done);
});

gulp.task('mcss', function (done) {
    gulp.src('./www/**/*.css')
        .pipe(gulpif('*.css', minifyCss()))
        .pipe(gulp.dest('./dist'))
        .on('end', done);
});

gulp.task('ojs', function (done) {
  gulp.src('./www/**/controller1.js')
    .pipe(concat('./js/app.js'))    //合并所有js到app.js
    .pipe(gulpif('*.js', ngAnnotate({single_quotes: true})))
    .pipe(gulpif('*.js', uglify()))
    .pipe(gulp.dest('./dist'))
    .on('end', done);
});

gulp.task('oojs', function (done) {
  gulp.src('./r/**/*.js')
    .pipe(concat('./js/app.js'))    //合并所有js到app.js
    .pipe(gulpif('*.js', uglify()))
    .pipe(gulp.dest('./dist'))
    .on('end', done);
});

var SRC_DIR = './www/';
var PKG_DIR = './tmp/pkg/';
var REV_DIR = './tmp/rev/';
var DST_DIR = './dist/';

/*
 * 压缩IMG,拷贝资源类文件(例如svg等)
 *
 */
gulp.task('imgmin', function() {
  return gulp.src([SRC_DIR + 'img/**/*.*(jpg|png|svg)', SRC_DIR + 'component/img/**/*.*(jpg|png)'])
    // .pipe(imagemin())
    // .pipe(gulpif('*.*(jpg|png)', imagemin()))
    .pipe(gulp.dest('./dist/img/'));
});

/*
 * 移动lib文件夹
 */
gulp.task('movelib', function() {
  // return gulp.src(SRC_DIR + 'lib/**/*')
  //   .pipe(gulp.dest(DST_DIR + 'lib/'));
  return gulp.src(SRC_DIR + 'lib/ionic/fonts/*')
    .pipe(gulp.dest(DST_DIR + 'lib/ionic/fonts/'));
});