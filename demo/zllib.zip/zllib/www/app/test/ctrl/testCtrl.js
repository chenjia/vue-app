// console.log(fff);
angular.module('app').controller('testCtrl', function ($scope,$rootScope,$ionicViewSwitcher, utils, testHandler,$document) {

    /**
     * 定义或初始化非双向绑定控制器内全局变量
     */
    var urlParams = '';

    var timer;
    // try{
    //     console.log(fff);
    // }catch (e){
    //     console.log(e);
    //     bLog.info('try',e.stack);
    // };
    
    // // 不包含数据的，描述为 init.succeed 的记录
    // bLog.info('b.log',{
    //     retcode: 'test',
    //     retmsg: 'invalid'
    // });

    //页面绑定对象与页面交互
    $scope.vo = {};
    //页面业务控制类绑定对象
    $scope.vc = {
        toMenu:function (param) {
            switch (param){
                case "testui":
                {
                    utils.ocload.load([
                        'app/testui/testui.js'
                    ]).then(function () {
                        utils.go('zl.pd.testui');
                    });
                }
                break;
                case "testDemo":
                {
                    // utils.ocload.load([
                    //     'app/testui/testui.js'
                    // ]).then(function () {
                        utils.go('zl.demo.home');
                    // });
                }
                    break;
                default :
                {}
            }
        },
        testTP:function () {
            testHandler.getCertCode().success(function (data) {
                console.log(data);
                testHandler.login({userName:'liws',password:zdes.encrypt('Taiping88'),certCode:data.data[0].code})
                    .success(function (data) {
                        console.log(data);
                        testHandler.inEntry().success(function (data) {
                            console.log(data);
                        });
                    }).error(function (data) {
                    console.log(data);
                });
            });
        }
    };

    function init() {
        //初始化数据方法
        //removeIf(zzdebug)
        // utils.ocload.load([
        //     'app/testui/testui.js'
        // ]).then(function () {
        //     $ionicViewSwitcher.nextDirection('none');
        //     // utils.go('testui');
        // });
        //endRemoveIf(zzdebug)
        /**/
    };

    $rootScope.$on('http_1', function(event,data) {
        console.log('http_1 ====', data);
    });

    $rootScope.$on('http999', function(event,data) {
        console.log('http999 ====', data);
    });

    /**
     * 方法定义
     */

    function test() {

        var data =
        {
            'first': {
                'number': 1,
                'text': 'Ya.'
            },
            'second': {
                'number': 10,
                'text': 'Da.'
            },
            "third": [
                {"number": 5, "text": "meh"},
                {"number": 6, "text": "beh"}
            ],
            'zh':'中文'
        };
        zzlogKey(data);
        zzlogKeyValue(data);

        console.log(Base64.encode(angular.toJson(data)));

        var res = Base64.decode(Base64.encode(angular.toJson(data)));

        console.log(res);

        console.log(angular.fromJson(res));

        utils.cookie.put('devId', 'HB04LXK3');
        utils.cookie.put('userId', '3');

        //获取UUID
        console.log(utils.uuid());
        console.log(utils.uuid());

        console.log(utils.up2tf('HSSDFA_FDFADF_DFADFA'));

        //日期格式化
        console.log(utils.date.dateFormat(new Date()));
        console.log(utils.date.dateFormat(new Date(),'yyyy-MM-dd'));
        //string转日期
        console.log(utils.date.toDate('2016-06-01'));
        console.log(utils.date.toDate('2016-06-01 01:00'));
        console.log(utils.date.toDate('2016-06-01 20:00:30'));
        console.log(utils.date.dateFormat(utils.date.toDate('2016-06-01'),'MM-dd'));
        console.log(utils.date.toDate('2016-06'));
        console.log(utils.date.toDate('2016-06 01:00'));
        console.log(utils.date.toDate('2016-06 20:00:30'));
        console.log(utils.date.dateFormat(utils.date.toDate('2016-06'),'MM-dd'));
        //根据日期计算年龄
        //年龄计算为实际年龄，包括了闰年的因素
        console.log(utils.date.getAge('1990-12-20'));
        console.log(utils.date.getAge('2016-12-20'));
        console.log(utils.date.getAge('2015-12-20'));
        console.log(utils.date.getAge('2015-12-19'));
        console.log(utils.date.getAge('2015-12-18'));
        console.log(utils.date.getAge('1992-12-21'));
        console.log(utils.date.getAge('1989-12-01'));
        console.log(utils.date.getAge('1989-12-01 00:00:00'));
        console.log(utils.date.getAge('1989-12-01 00:00'));
        console.log(utils.date.getAge('1990-12'));
        console.log(utils.date.getAge('2016-12'));
        console.log(utils.date.getAge('2015-12'));
        console.log(utils.date.getAge('2015-12'));
        console.log(utils.date.getAge('2015-12'));
        console.log(utils.date.getAge('1992-12'));
        console.log(utils.date.getAge('1989-12'));
        console.log(utils.date.getAge('1989-12 00:00:00'));
        console.log(utils.date.getAge('1989-12 00:00'));
        console.log(utils.date.getAge('19891201'));
        console.log(utils.date.getAge('fasdfasd'));
        //专为恒大特殊判断，如果是当天，年龄减一岁
        console.log(utils.date.getAgeT('1990-12-20'));
        console.log(utils.date.getAgeT('1990-12-20','2015-12-20'));
        console.log(utils.date.getAgeT('2016-12-20'));
        console.log(utils.date.getAgeT('1990-12-19'));
        console.log(utils.date.getAgeT('2016-12-19'));
        console.log(utils.date.getAgeT('1990-12-21'));
        console.log(utils.date.getAgeT('2016-12-21'));
        //根据年龄计算生日
        console.log(utils.date.getBirthday(20));

        $scope.ceshi = angular.copy(utils.bo.boTest);
        console.log($scope.ceshi.hello);

        var testBo1 = angular.copy(utils.bo.boLogin);
        testBo1.username  = 'test';
        testBo1.password  = 'password';
        //将对象属性的值置空
        console.log(utils.jsonToNull(testBo1));

        var testBo2 = angular.copy(utils.bo.boLogin);
        testBo2.username  = 'test2';
        //将对象的null以及undefined属性去除
        console.log(utils.jsonNoNull(testBo2));

        console.log(utils.htag.htag_login);

        console.log(zutils.htag.htag_login);

        var testdes = zdes.decrypt(zdes.encrypt('Taiping88'));
        console.log(testdes);

        function callback(data) {
            console.log(data);
        }
        testHandler.testFunc('testData',callback);

        testHandler.testFuncForGY('testData',callback);

        utils.timeout(function () {
            console.log('utils.timeout after 5s');
        },5000);

        //removeIf(zzdebug)
        utils.cookie.put('cookieKey', 'test cookie');
        console.log(utils.cookie.get('cookieKey'));
        utils.cookie.remove('cookieKey');
        console.log(utils.cookie.get('cookieKey'));
        console.log(Object.prototype.toString.call(''));   // [object String]
        console.log(Object.prototype.toString.call(1));    // [object Number]
        console.log(Object.prototype.toString.call(true)); // [object Boolean]
        console.log(Object.prototype.toString.call(undefined)); // [object Undefined]
        console.log(Object.prototype.toString.call(null)); // [object Null]
        console.log(Object.prototype.toString.call(new Function())); // [object Function]
        console.log(Object.prototype.toString.call(new Date())); // [object Date]
        console.log(Object.prototype.toString.call([])); // [object Array]
        console.log(Object.prototype.toString.call(new RegExp())); // [object RegExp]
        console.log(Object.prototype.toString.call(new Error())); // [object Error]
        console.log(Object.prototype.toString.call(document)); // [object HTMLDocument]
        console.log(Object.prototype.toString.call(window)); //[object global] window是全局对象
        //endRemoveIf(zzdebug)

        timer = utils.interval(function () {
            console.log('*********');
        },1000*1,3)// 表示每一秒执行一次，执行三次
            .then(function () {// 三次成功后调用对应的函数
            console.log('end');
        });
        //加减乘除
        console.log(utils.double.add('10.101','20.111'));
        console.log(utils.double.sub('10.101','20.111'));
        console.log(utils.double.mul('10.101','20.111'));
        console.log(utils.double.div('10.101','20.111'));

        testHandler.testGetJson(null,function (data) {
            if(data.CODE)
            {
                console.log('testGetJson success');
                console.log(data.data);
            }
            else
                console.log('testGetJson failed');
        });

        testHandler.testDq('testDq')
        // testHandler.testDq({test:'%'})
            .success(function (data) {
                console.log(data);
            }).error(function (data) {
            console.log(data);
        });

        //本地存储
        utils.locals.set('testLocals',{hello:'fafdasd'});

        var testLocals = utils.locals.get('testLocals');

        console.log(testLocals);

        utils.locals.clearAll();

        testLocals = utils.locals.get('testLocals');
        console.log(testLocals);

        utils.locals.set('testLocals',{hello:'fafdasd'});

        utils.locals.remove('testLocals');

        utils.locals.set('testLocals',{hello:'fafdasd'},'login');
        utils.locals.set('testLocals1',{hello1:'gsdfgsfhsd'},'login');
        utils.locals.set('testLocals',{hello:'kfhhgfghjhgj'});

        testLocals = utils.locals.get('testLocals','login');
        console.log(testLocals);

        testLocals = utils.locals.get('testLocals');
        console.log(testLocals);

        utils.locals.clearAll('login');

        testLocals = utils.locals.get('testLocals','login');
        console.log(testLocals);

        testLocals = utils.locals.get('testLocals');
        console.log(testLocals);

        //码表取值
        console.log(utils.CODE.cardCode);

        console.log(utils.check.isID('11010219820101985X'));

        //原生调用h5的入口方法
        nativeCall('hybrid://native_web_id/vc.native2web?{\"hello\":\"helloValue\",\"test\":\"hehe\"}');

        //判断参数是否为空
        console.log(utils.isNull());
        console.log(utils.isNull(null));
        console.log(utils.isNull(''));
        console.log(utils.isNull('hello'));

        //测试调用原生插件
        if(window.cordova)
        {
            utils.timeout(function () {
                var testjs = 'hybrid://ZLManageData:401/queryMainInsuranceList';
                console.log(testjs);
                MAPlugin.callNative(testjs);
            },10000);
        }
    }

    //removeIf(zzdebug)
    // $scope.vc.toMenu = function(type){
    //     //控制跳转动画
    //     // if(type=='tabs.jour'){
    //     //     $ionicViewSwitcher.nextDirection('forward');
    //     // }else{
    //     //     $ionicViewSwitcher.nextDirection('none');
    //     // }
    //     $ionicViewSwitcher.nextDirection('none');
    //     utils.go(type);
    // };

    // utils.timeout(function () {
    //     utils.ocload.load([
    //         'app/demo/demo.js'
    //     ]).then(function () {
    //         utils.go('index');
    //     });
    // },5000);

    // $scope.onDragUp = function(){
    //     $rootScope.tabsshow="hide";
    //     // console.log($rootScope.tabsshow);
    // };
    //
    // $scope.onDragDown= function(){
    //     // console.log($rootScope.tabsshow);
    //     $rootScope.tabsshow="";
    // };
    //endRemoveIf(zzdebug)

    function tabInit() {
        var tab = $document[0].querySelector(".tabs-positive-foot");
        $rootScope.$on("$ionicView.beforeEnter", function (event, data) {
            switch (data.stateName) {
                case "zl.home":
                    if (tab !== null && tab !== undefined)
                        tab.classList.remove("hide");
                    break;
                default:
                    if (tab !== null && tab !== undefined)
                        tab.classList.add("hide");
                    //设置顶部bar样式
                    break;
            }
        });
    }

    //如需调用原生，则需在此方法中调用。
    // utils.ionic.ready(function () {
    //     tabInit();
    //     test();
    // });

    /**
     * 初始化流程(需后台调用 或 立即执行 等流程类方法)
     */
    // $scope.ready = function () {
    //     tabInit();
    //     test();
    // }();

    $scope.$on("$ionicView.beforeEnter", function(event, data) {
        //页面加载之前执行
        init();
    });
    $scope.$on("$ionicView.afterEnter", function(event, data) {
        //页面加载之后执行
        test();
    });
    $scope.$on("$ionicView.beforeLeave", function(event, data) {
        //离开页面之前执行
    });
    $scope.$on("$ionicView.afterLeave", function(event, data) {
        //离开页面之后执行
    });

    $scope.$on("$destroy", function() {
            utils.interval.cancel(timer);
        }
    );
});
