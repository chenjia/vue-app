angular.module('app').factory('testHandler', function (utils) {
    return {

        /**
         *
         * @param reqData
         * @param callback
         * @param mode
         */
        testFunc: function (reqData, callback, mode) {
            
            // start();

            var postObj = angular.copy(utils.bo.boTest);
            postObj.hello = reqData.test;

            utils.http(utils.htag.htag_login, postObj).success(function (data, status, headers, config) {
                console.log('success ' + angular.toJson(data) + ' ' + status);
                callback(data);
            }).error(function (data, status, headers, config) {
                callback(data);
            });
        },

        /**
         *
         * @param reqData
         * @param callback
         * @param mode
         */
        testFuncForGY: function (reqData, callback, mode) {

            // start();

            var postObj = angular.copy(utils.bo.boTest);
            postObj.hello = reqData.test;

            utils.http({url:'app/test/data/testForGY.json',mode:"GET"}).success(function (data, status, headers, config) {

                utils.http(utils.htag.htag_test_gy, data).success(function (data, status, headers, config) {
                    console.log('success ' + angular.toJson(data) + ' ' + status);
                    // var result = utils._(data);
                    // callback(result);
                }).error(function (data, status, headers, config) {
                    // var result = utils._(data);
                    // callback(result);
                });

            }).error(function (data, status, headers, config) {

            });
        },

        /**
         *
         * @param url
         * @param callback
         * @param mode
         */
        testGetJson: function (url, callback, mode) {

            var result = {CODE:null,data:null};

            // utils.httpGet('app/test/data/test.json').success(function (data, status, headers, config) {
            //     console.log('success ' + angular.toJson(data) + ' ' + status);
            //     result.CODE = true;
            //     result.data = data;
            //     callback(result);
            // }).error(function (data, status, headers, config) {
            //     console.log('error ' + angular.toJson(data) + ' ' + status);
            //     result.CODE = false;
            //     result.data = data;
            //     callback(result);
            // });

            utils.http({url:'app/test/data/test.json',mode:"GET"}).success(function (data, status, headers, config) {
                console.log('success ' + angular.toJson(data) + ' ' + status);
                result.CODE = true;
                result.data = data;
                callback(result);
            }).error(function (data, status, headers, config) {
                console.log('error ' + angular.toJson(data) + ' ' + status);
                result.CODE = false;
                result.data = data;
                callback(result);
            });
        },

        testDq: function (reqData, mode) {

            var postObj = angular.copy(utils.bo.boTest);
            postObj.hello = reqData.test;

            var def = utils.defer();

            utils.http({smid:"30003",url:"https://agenttest.icbc-axa.com/ssm_server_ipad/callServiceByMobile.do"}, postObj).success(function (data, status, headers, config) {
                console.log('success ' + angular.toJson(data) + ' ' + status);
                return def.resolve(data);
            }).error(function (data, status, headers, config) {
                return def.reject(data);
            });
            return def.promise;
        },

        getCertCode: function (reqData, mode) {
            var def = utils.defer();
            utils.http(utils.htag.htag_getCertCode).success(function (data, status, headers, config) {
                console.log('success ' + angular.toJson(data) + ' ' + status);
                utils.cookie.put('token', headers('token'));
                return def.resolve(data);
            }).error(function (data, status, headers, config) {
                return def.reject(data);
            });
            return def.promise;
        },

        login: function (reqData) {
            var def = utils.defer();
            utils.http(utils.htag.htag_login, reqData).success(function (data, status, headers, config) {
                console.log('success ' + angular.toJson(data) + ' ' + status);
                utils.cookie.put('token', headers('token'));
                return def.resolve(data);
            }).error(function (data, status, headers, config) {
                return def.reject(data);
            });
            return def.promise;
        },

        inEntry: function (reqData, mode) {
            var def = utils.defer();
            utils.http(utils.htag.htag_inEntry).success(function (data, status, headers, config) {
                console.log('success ' + angular.toJson(data) + ' ' + status);
                return def.resolve(data);
            }).error(function (data, status, headers, config) {
                return def.reject(data);
            });
            return def.promise;
        },

        // testLogin: function (reqData, mode) {
        //
        //     var def = utils.defer();
        //
        //     // $.ajax({
        //     //     url: 'http://10.7.204.23/sfss-web/portal/loadIdentifyCodeRestful.do',
        //     //     // headers: {'test': 'test'},
        //     //     method: 'GET'
        //     // }).then(function(data, status, xhr) {
        //     //     console.log(xhr.getAllResponseHeaders());
        //     // });
        //
        //     utils.http({url:"http://10.7.204.23/sfss-web/portal/loadIdentifyCodeRestful.do"}).success(function (data, status, headers, config) {
        //         console.log(headers());
        //         console.log('success ' + angular.toJson(data) + ' ' + status);
        //         utils.http({url:"http://10.7.204.23/sfss-web/loginRestful.do"}, {userName:'liws',password:zdes.encrypt('Taiping88'),certCode:data.data[0].code},{headers: {'token': headers('token')}}).success(function (data, status, headers, config) {
        //             console.log(headers());
        //             console.log('success ' + angular.toJson(data) + ' ' + status);
        //             // var result = utils._(data);
        //
        //             utils.cookie.put('token', headers('token'));
        //             utils.http({url:"http://10.7.204.23/sfss-web/inEntryRestful.do"}, {}).success(function (data, status, headers, config) {
        //                 console.log('success ' + angular.toJson(data) + ' ' + status);
        //                 // var result = utils._(data);
        //                 // return def.resolve(data);
        //             }).error(function (data, status, headers, config) {
        //                 // var result = utils._(data);
        //                 // return def.reject(data);
        //             });
        //
        //             return def.resolve(data);
        //         }).error(function (data, status, headers, config) {
        //             // var result = utils._(data);
        //             return def.reject(data);
        //         });
        //         // var result = utils._(data);
        //         // return def.resolve(data);
        //     }).error(function (data, status, headers, config) {
        //         // var result = utils._(data);
        //         // return def.reject(data);
        //     });
        //
        //     // utils.http({url:"http://10.7.204.23/sfss-web/loginRestful.do"}, reqData).success(function (data, status, headers, config) {
        //     //     console.log('success ' + angular.toJson(data) + ' ' + status);
        //     //     // var result = utils._(data);
        //     //     return def.resolve(data);
        //     // }).error(function (data, status, headers, config) {
        //     //     // var result = utils._(data);
        //     //     return def.reject(data);
        //     // });
        //     return def.promise;
        // },

    };
});
