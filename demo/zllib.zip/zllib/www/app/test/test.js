angular.module('app.route').config(function ($stateProvider) {
    $stateProvider
        .state('zl.test', {
            url: "/test",
            // abstract: true, //是否可以直接访问
            templateUrl: function () {
                return 'app/test/view/test.html';//配置路由对于页面
            },
            controller: 'testCtrl',//页面对于controller
            resolve: {//配置需要的controller、handler等资源
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        'app/test/ctrl/testCtrl.js',
                        'app/test/service/testHandler.js'
                    ]);
                }]
            }
        })
    ;
});
/*
 * 模块入口JS（需在main.js中引入，routerList中加入）
 * 配置模块路由
 */