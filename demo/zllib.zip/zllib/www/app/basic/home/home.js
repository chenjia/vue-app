angular.module('app.route').config(function ($stateProvider) {
    // $stateProvider
    //     .state('zl.pd', {
    //         url: "/pd",
    //         // templateUrl: function(){
    //         //     return 'app/basic/root/view/zlpd.html';
    //         // },
    //         template: "<div class=\"header\"><div ng-include=\"'app/basic/home/view/header.html'\"></div></div><ion-nav-view>main</ion-nav-view><div class=\"tabs-positive-foot\"><div ng-include=\"'app/basic/home/view/tabs.html'\"></div></div>",
    //         controller: function() {},
    //         resolve: {
    //             load: ['$ocLazyLoad', function ($ocLazyLoad) {
    //                 return $ocLazyLoad.load(lazyloadlib);
    //             }]
    //         }
    //     })
    // ;
});
