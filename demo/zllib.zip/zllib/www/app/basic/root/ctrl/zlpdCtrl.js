angular.module('app').controller('zlpdCtrl', function ($scope, $rootScope, utils,zutils) {
    //初始化
    (function init() {
        $scope.vc = {};
        $scope.$on("$ionicView.afterEnter", function (event, data) {
            utils.ocload.load(lazyloadlib);
        });
        zutils.init();
        window.zutils = utils;
    })();

    $scope.vc.native2web = function (parm) {
        console.log(parm);
        return 'native2web func return value';
    };

    $rootScope.$on('$stateChangeSuccess',function(event, toState, toParams, fromState, fromParams) {
        var fromModule=fromState.name.split(".")[1]||"null";
        var toModule=toState.name.split(".")[1]||"null";
        console.log(fromModule+' *****  to  ***** '+toModule);

        // Logline.all(function(logs) {
        //     // process logs here
        //     console.log(logs);
        //     console.log(navigator.userAgent);
        //     if(logs.length==0){
        //         return;
        //     }
        //     var infoList = [];
        //     for(var i=0; i< logs.length;i++){
        //         infoList.push(angular.toJson(logs[i]));
        //     }
        //     var result ={
        //         ip:(typeof returnCitySN !== "undefined")?returnCitySN.cip:'',
        //         binfo:navigator.userAgent,
        //         errorlist:infoList
        //     };
        //
        //     console.log(result);
        //     // Logline.clean();
        // });
    });
});