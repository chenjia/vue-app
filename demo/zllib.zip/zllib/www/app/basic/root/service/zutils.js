angular.module('app').factory('zutils', function (
    utils,
    $filter,
    $interval,
    $location,
    // $compile,
    $templateRequest,

    $ionicPopup,
    $ionicModal,
    $ionicHistory,
    $ionicLoading,
    $ionicPopover,
    $ionicPlatform,
    $ionicPosition,
    $ionicScrollDelegate,
    $ionicNavBarDelegate,
    $ionicViewSwitcher,
    $ionicSlideBoxDelegate,
    $ionicSideMenuDelegate,

    check_Utils,
    codeFactory
){
    var zutils = {
        init:function () {
            utils.version = 'v0.01';
            utils.$ionicPlatform = $ionicPlatform;
            utils.ionic = $ionicPlatform;
            utils.$ionicPopup = $ionicPopup;
            utils.$ionicModal = $ionicModal;
            utils.$ionicHistory = $ionicHistory;
            utils.$ionicLoading = $ionicLoading;
            utils.ionicPopover = $ionicPopover;
            utils.$ionicPopover = $ionicPopover;
            utils.$filter = $filter;
            utils.$interval = $interval;
            utils.$location = $location;
            // utils.$compile = $compile;
            utils.$templateRequest = $templateRequest;
            utils.$ionicPosition = $ionicPosition;
            utils.$ionicScrollDelegate = $ionicScrollDelegate;
            utils.$ionicNavBarDelegate = $ionicNavBarDelegate;
            utils.$ionicViewSwitcher = $ionicViewSwitcher;
            utils.$ionicSlideBoxDelegate = $ionicSlideBoxDelegate;
            utils.$ionicSideMenuDelegate = $ionicSideMenuDelegate;
            utils.CODE = codeFactory;
            utils.check = check_Utils;
        },
    };
    return zutils;
});
