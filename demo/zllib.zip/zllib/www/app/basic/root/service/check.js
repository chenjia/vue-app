angular.module('app.route').factory('check_Utils', function() {
	var Email = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/,
		ZiMuOrNum = /^[\da-z]+$/i,
		ZeroStartNum = /^(0[0-9]*)$/,
		UnZeroStartNum = /^([1-9][0-9]*)$/,
		Mobile = /^(13|15|18)\d{9}$/,
		Telephone = /^((0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/,
		ZiMu = /^[a-zA-Z]+$/,
		ZiMuOrHanzi = /^[a-z A-Z\u4E00-\u9FA5]+$/,
		HanZi = /^[\u4E00-\u9FA5]+$/, ///^[\u4E00-\u9FA5]+$/
		CarNo = /^[\u4e00-\u9fa5]{1}[A-Z]{1}[A-Z_0-9]{5}$/,
		QQNo = /^[1-9]\d{4,10}$/,
		ValidTrueName = /^[A-Z \u4E00-\u9FA5]+$/,
		// ShuZi = /^\d+$/,
		PostCode = /^[1-9][0-9]{5}$/,
		IsInteger = /^[0-9]*[1-9][0-9]*$/;

	//	Url = /s/;
	/**
	 * 正则验证
	 * @param {Object} str 需要验证的str
	 * @param {Object} regStr 正则str
	 */
	function regexStr(str, regStr) {
		if(str && str.length == 0) {
			return false
		} else if(!regStr.test(str)) {
			return false;
		}
		return true;
	}
	return {

		/**
		 * 验证是否是有效地邮政编码
		 * @param {Object} emailStr
		 */
		isrEmail: function(emailStr) {
			return regexStr(emailStr, Email);
		},
		/**
		 * 验证由字母、数字组成的字符串
		 * @param {Object} numStr
		 */
		isrZiMuOrNum: function(numStr) {
			return regexStr(numStr, ZiMuOrNum);
		},
		/**
		 * 验证字符串长度是否在min到max之间
		 * @param {Object} min 最小值
		 * @param {Object} max 最大值
		 * @param str
		 */
		isrLengthMin: function(min, max, str) {
			//			return regexStr(str, LengthMin);
		},
		/**
		 * 断是否为全英文大写或全中文，可以包含空格
		 * @param {Object} strName
		 */
		isrValidTrueName: function(strName) {
			return regexStr(strName, ValidTrueName);
		},
		/**
		 * 验证零开头的数字字符串
		 * @param {Object} str
		 */
		isrZeroStartNum: function(str) {},
		/**
		 * 验证非零开头的数字字符串
		 * @param {Object} str
		 */
		isrUnZeroStartNum: function(str) {},
		/**
		 * 判断是否为手机号码
		 * @param {Object} str
		 */
		isrMobile: function(str) {
			return regexStr(str, Mobile);
		},
		/**
		 * 验证固定电话
		 * @param {Object} str
		 */
		isrTelephone: function(str) {
			return regexStr(str, Telephone);
		},
		/**
		 * 验证字母组成的字符串
		 * @param {Object} str
		 */
		isrZiMu: function(str) {
			return regexStr(str, ZiMu);
		},
		/**
		 * 验证字母与汉字混合
		 * @param {Object} str
		 */
		isrZiMuOrHanzi: function(str) {
			return regexStr(str, ZiMuOrHanzi);
		},
		/**
		 * 验证是否为汉字
		 * @param {Object} str
		 */
		isrHanZi: function(str) {
			return regexStr(str, HanZi);
		},
		/**
		 * 验证车牌号
		 * @param str
		 */
		isrCarNo: function(str) {
			return regexStr(str, CarNo);
		},
		/**
		 * 验证是否为QQ
		 * @param {Object} str
		 */
		isrQQNo: function(str) {
			return regexStr(str, QQNo);
		},
		/**
		 * 验证IP
		 * @param {Object} strIP
		 */
		isrIP: function(strIP) {
			//			if(isNull(strIP)) return false;
			var re = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/g; //匹配IP地址的正则表达式
			if(re.test(strIP)) {
				if(RegExp.$1 < 256 && RegExp.$2 < 256 && RegExp.$3 < 256 && RegExp.$4 < 256) return true;
			}
			return false;
		},
		/**
		 * 验证网址
		 * @param {Object} str
		 */
		isrUrl: function(str) {
			//			return regexStr(str, Url);
		},
		/**
		 * 根据正则表达式验证字符串
		 * @param {Object} str
		 * @param {Object} regStr
		 */
		isrWithRegexStr: function(str, regStr) {
			return regexStr(str, regStr);
		},
		/**
		 * 身份证校验
		 * @param {Object} idStr 身份证字符串
		 * @param {Object} area  地区
		 * 返回 成功 返回身份证信息 失败返回false
		 * ***0是女 1是男
		 */
		isID: function(idStr) {
			var oldCode = angular.copy(idStr);
			idStr = idStr.toUpperCase();
			var city = {
				11: "北京",
				12: "天津",
				13: "河北",
				14: "山西",
				15: "内蒙古",
				21: "辽宁",
				22: "吉林",
				23: "黑龙江 ",
				31: "上海",
				32: "江苏",
				33: "浙江",
				34: "安徽",
				35: "福建",
				36: "江西",
				37: "山东",
				41: "河南",
				42: "湖北 ",
				43: "湖南",
				44: "广东",
				45: "广西",
				46: "海南",
				50: "重庆",
				51: "四川",
				52: "贵州",
				53: "云南",
				54: "西藏 ",
				61: "陕西",
				62: "甘肃",
				63: "青海",
				64: "宁夏",
				65: "新疆",
				71: "台湾",
				81: "香港",
				82: "澳门",
				91: "国外 "
			};
			var tip = "";
			var pass = true;

			if(!idStr || !/^\d{6}(18|19|20)?\d{2}(0[1-9]|1[12])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i.test(idStr)) {
				tip = "身份证号格式错误";
				pass = false;
			} else if(!city[idStr.substr(0, 2)]) {
				tip = "地址编码错误";
				pass = false;
			} else {
				//18位身份证需要验证最后一位校验位
				if(idStr.length == 18) {
					idStr = idStr.split('');
					//∑(ai×Wi)(mod 11)
					//加权因子
					var factor = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
					//校验位
					var parity = [1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2];
					var sum = 0;
					var ai = 0;
					var wi = 0;
					for(var i = 0; i < 17; i++) {
						ai = idStr[i];
						wi = factor[i];
						sum += ai * wi;
					}
					var last = parity[sum % 11];
					if(parity[sum % 11] != idStr[17]) {
						tip = "校验位错误";
						pass = false;
					}
				}
			}
			if(!pass) {
				// console.log(tip);
				return false;
			} else {
				// console.log(idStr);
				var sex = oldCode.length == 15 ? oldCode.substr(14, 1) % 2 : oldCode.substr(16, 1) % 2;
				sex == 0 ? sex = 2 : sex = 1;
				return {
					cityCode: oldCode.substr(0, 4),
					cityDesc: city[oldCode.substr(0, 2)],
					birthDay: oldCode.substr(6, 4) + "-" + oldCode.substr(10, 2) + "-" + oldCode.substr(12, 2),
					sex: sex
				};
			}
		},
		/**
		 * 数字校验 (判断类型是否为数字)
		 * @param {Object} numStr 数字校验
		 */
		isNumber: function(numStr) {
			return angular.isNumber(numStr);
		},
		/**
		 * 判断是否为正整数
		 */
		isInteger: function(numStr) {
			return regexStr(numStr, IsInteger);
		},
		/**
		 * 邮编校验
		 * @param {Object} postStr
		 */
		isPostCode: function(postStr) {
			return regexStr(postStr, PostCode);
		}
	};
});