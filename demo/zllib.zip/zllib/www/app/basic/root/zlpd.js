angular.module('app.route').config(function ($stateProvider) {
    $stateProvider
        .state('zl', {
            url: "/zl",
            // templateUrl: function(){
            //     return 'app/basic/root/view/zlpd.html';
            // },
            template:"<ion-nav-view id='native_web_id'></ion-nav-view>",
            //removeIf(zzdebug)
            // template: "<ion-nav-view></ion-nav-view><div class=\"tabs-positive-foot\"></div>",
            //endRemoveIf(zzdebug)
            controller: 'zlpdCtrl',
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(libListOfZl.concat([
                        'app/basic/root/ctrl/zlpdCtrl.js',
                    ]));
                }]
            }
        })
        .state('zl.pd', {
            url: "/pd",
            // templateUrl: function(){
            //     return 'app/basic/root/view/zlpd.html';
            // },
            template: "<ion-nav-view></ion-nav-view>",
            controller: function() {},
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load(lazyloadlib);
                }]
            }
        })
    ;
});
