angular.module('app').factory('demoHandler', function (utils) {
    return {
        /**
         *
         * @param reqData
         * @param callback
         * @param mode
         */
        testFunc: function (reqData, callback, mode) {

            var result = {CODE: null, data: null};
            // start();

            var postObj = angular.copy(utils.bo.boTest);
            postObj.hello = reqData.test;

            utils.http(utils.htag.htag_login, postObj).success(function (data, status, headers, config) {
                console.log('success ' + angular.toJson(data) + ' ' + status);
                result.CODE = true;
                result.data = data;
                callback(result);
            }).error(function (data, status, headers, config) {
                result.CODE = false;
                result.data = data;
                callback(result);
            });
        },

    };
});
