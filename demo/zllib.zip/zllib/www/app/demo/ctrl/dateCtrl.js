angular.module('app').controller('dateCtrl', function ($scope, utils) {
    //页面绑定对象与页面交互
    $scope.vo = {
        date:'2016-04-15',
        date1:'2017-04-15'
    };
    //页面业务控制类绑定对象
    $scope.vc = {
        goBack:function () {
            utils.goBack();
        }
    };

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        //页面加载之后执行
        console.log("$ionicView.afterEnter");
    });
});
