angular.module('app').controller('calendarCtrl', function ($scope, utils) {
    //页面绑定对象与页面交互
    $scope.vo = {

    };
    //页面业务控制类绑定对象
    $scope.vc = {
        goBack:function () {
            utils.goBack();
        },
    };

    var now = new Date();
//https://demo.mobiscroll.com/javascript/select/basic#lang=zh
    $scope.vo.calendar = mobiscroll.calendar('#calendar', {
        display: 'inline',
        layout: 'liquid',
        theme: 'material',
        lang:'zh',
        firstSelectDay:1,
        markedDisplay: 'bottom',
        marked:[
            {
                d: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 5),
                color: 'rgb(28, 161, 227)'
            }, {
                d: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 6),
                color: 'rgb(28, 161, 227)'
            }, {
                d: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 7),
                color: 'rgb(28, 161, 227)'
            }, {
                d: new Date(now.getFullYear(), now.getMonth() + 1, 15),
                color: 'rgb(28, 161, 227)'
            },
            // {
            //     d: '11/30',
            //     color: 'rgb(163, 0, 38)'
            // }, {
            //     d: '5/23',
            //     color: 'rgb(163, 0, 38)'
            // }, {
            //     d: '3/12',
            //     color: 'rgb(163, 0, 38)'
            // }, {
            //     d: '14',
            //     color: 'rgb(204,204,0)'
            // }, {
            //     d: 'w5',
            //     color: 'rgb(34, 139, 34)'
            // }, {
            //     d: '1/1',
            //     color: 'rgb(250,104,0)'
            // }, {
            //     d: '1/2',
            //     color: 'rgb(250,104,0)'
            // }, {
            //     d: '6/4',
            //     color: 'rgb(250,104,0)'
            // }, {
            //     d: '8/4',
            //     color: 'rgb(250,104,0)'
            // }, {
            //     d: '12/25',
            //     color: 'rgb(250,104,0)'
            // }, {
            //     d: '12/26',
            //     color: 'rgb(250,104,0)'
            // }
        ],
        onDayChange:function(event, inst){
            var dateStr = mobiscroll.util.datetime.formatDate('yyyy-mm-dd',event.date);
            console.log(dateStr);
            // $scope.vo.date = dateStr;
            // $scope.vc.changeDate(dateStr);
            // $scope.dateModal.hide();
            // $scope.$apply();
        },
        onMonthChange:function(event, inst){
            // activityHandler.queryActivityList({agentCode:'2',datetime:event.year+'-'+(event.month+1),activityType:"'3'"}).then(function(response){
            //     var activityList = $scope.vc.formatParam(response.activityList);
            //     var events = [];
            //     for(var i=0;i<activityList.length;i++){
            //         var activityDateArray = activityList[i].activityDate.split('-');
            //         events.push({
            //             d:new Date(parseInt(activityDateArray[0]),parseInt(activityDateArray[1]-1),parseInt(activityDateArray[2])),
            //             icon:'paw'
            //         });
            //     }
            //     $scope.vo.calendar.option({
            //         defaultValue:new Date(event.year,event.month,parseInt($scope.vo.date.substr(8))),
            //         events:events
            //     });
            // },function(e){
            //     utils.JAlert.alertOnce('查询活动列表失败！');
            // });
            console.log(event.year +'  '+ (event.month+1));
        }
    });

    /**-----------------------分页-end--------------------------------------*/

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        //页面加载之后执行
        console.log("$ionicView.afterEnter");
    });
});
