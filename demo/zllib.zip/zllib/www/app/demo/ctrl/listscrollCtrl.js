angular.module('app').controller('listscrollCtrl', function ($scope, utils) {
    //页面绑定对象与页面交互
    $scope.vo = {
        items :[
            { id: 0 },
            { id: 1 },
            { id: 2 },
            { id: 3 },
            { id: 4 },
            { id: 5 },
            { id: 6 },
            { id: 7 },
            { id: 8 },
            { id: 9 },
            { id: 10 },
            { id: 11 },
            { id: 12 },
            { id: 13 },
            { id: 14 },
            { id: 15 },
            { id: 16 },
            { id: 17 },
            { id: 18 },
            { id: 19 },
            { id: 20 },
            { id: 21 },
            { id: 22 },
            { id: 23 },
            { id: 24 },
            { id: 25 },
            { id: 26 },
            { id: 27 },
            { id: 28 },
            { id: 29 },
        ]
    };
    var listLocation = null;
    //页面业务控制类绑定对象
    $scope.vc = {
        goBack:function () {
            utils.goBack();
        },
        getMLocation : function(){//第一次点击详情的位置
            listLocation =  utils.$ionicScrollDelegate.$getByHandle('mScroll').getScrollPosition();
            console.log(listLocation)
        },
        goTo:function(){
            utils.$ionicScrollDelegate.$getByHandle('mScroll').scrollTo(0,listLocation.top)
        }
    };

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        //页面加载之后执行
        console.log("$ionicView.afterEnter");
    });
});
