angular.module('app').controller('demoCtrl', function ($scope, utils, demoHandler) {
    // console.log('hello demo');
    //页面绑定对象与页面交互
    $scope.vo = {
        demolist:[
            {key:'accessory-附件',tag:0},
            {key:'address-省市区',tag:1},
            {key:'datepicker-日期选择',tag:2},
            {key:'echart-图表',tag:3},
            {key:'分页选择控件',tag:4},
            {key:'列表滚动示例',tag:5},
            {key:'手风琴示例',tag:6},
            {key:'浏览文件',tag:7},
            {key:'日历插件',tag:8}
        ]
    };
    //页面业务控制类绑定对象
    $scope.vc = {
        popover:undefined,
        openModal:function ($event) {
            if($scope.vc.popover){
                $scope.vc.popover.show($event);
            }else{
                utils.$ionicPopover.fromTemplateUrl('app/demo/view/demolist.html',{
                    scope:$scope
                }).then(function (popover) {
                    $scope.vc.popover = popover;
                    $scope.vc.popover.show($event);
                });
            }
        },
        demoClick:function ($index) {
            console.log($index);
            console.log($scope.vo.demolist[$index]);
            switch ($scope.vo.demolist[$index].tag) {
                case 2:
                    utils.go('zl.demo.date');
                    break;
                case 4:
                    utils.go('zl.demo.page');
                    break;
                case 5:
                    utils.go('zl.demo.scroll');
                    break;
                case 6:
                    utils.go('zl.demo.acc');
                    break;
                case 7:
                    utils.go('zl.demo.file');
                    break;
                case 8:
                    utils.go('zl.demo.cal');
                    break;
                default:
                    break;
            }
            $scope.vc.popover.hide();
        }
    };

    $scope.$on('$destroy', function() {
        $scope.vc.popover.remove();
    });

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        //页面加载之后执行
        console.log("$ionicView.afterEnter");
    });
});
