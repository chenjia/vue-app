angular.module('app').controller('pageCtrl', function ($scope, utils) {
    //页面绑定对象与页面交互
    $scope.vo = {
        params:{
            totalCount:216,//一共多少条数据
            pageIndex:1,//当前页码
            pageSize:10,//每页显示多少条数据
        }
    };
    //页面业务控制类绑定对象
    $scope.vc = {
        goBack:function () {
            utils.goBack();
        },
        pageChange:function (index) {
            // console.log('pageChange '+index);
            console.log('pageIndex ' +$scope.vo.params.pageIndex);
            // utils.timeout(function () {
            //     $scope.vo.params.pageIndex=5;
            //     // $scope.$apply();
            // },5000);

        }
    };

    /**-----------------------分页-start------------------------------------*/
    //分页-数据
    $scope.vo.page = {
        pageNo:1, //当前第几页
        pageNum:10, //总共有多少页
        totalNum:100
    };

    /**
     * @detail 分页-回调的函数
     * @param state 触发的事件名字 start：首页，up：上一页，down：下一页，end：尾页
     * @param value 返回的页数,eg:如果当前是第三页，点击上一页，返回的页数为：4
     */
    $scope.vc.callbackPage =function(state,value){
        $scope.vo.page.pageNo = value;
        console.log('点击了'+state+",回调值为："+value)
    };
    /**-----------------------分页-end--------------------------------------*/

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        //页面加载之后执行
        console.log("$ionicView.afterEnter");
    });
});
