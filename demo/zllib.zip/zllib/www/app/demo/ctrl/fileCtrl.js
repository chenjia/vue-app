angular.module('app').controller('fileCtrl', function ($scope, utils) {
    //页面绑定对象与页面交互
    $scope.vo = {
        params:{
            totalCount:216,//一共多少条数据
            pageIndex:1,//当前页码
            pageSize:10,//每页显示多少条数据
        }
    };
    //页面业务控制类绑定对象
    $scope.vc = {
        goBack:function () {
            utils.goBack();
        },
        pageChange:function (index) {
            // console.log('pageChange '+index);
            console.log('pageIndex ' +$scope.vo.params.pageIndex);
            // utils.timeout(function () {
            //     $scope.vo.params.pageIndex=5;
            //     // $scope.$apply();
            // },5000);

        }
    };

    //解析Excel
    function handleFile(e) {
        console.log(e)
        // scope.excelPath = e.target.value;
        // scope.$digest();
        // debugger
        var files = e.target.files;
        var i, f;

        if (FileReader.prototype.readAsBinaryString === undefined) {
            FileReader.prototype.readAsBinaryString = function (fileData) {
                var binary = "";
                var pt = this;
                var reader = new FileReader();
                reader.onload = function (e) {
                    var bytes = new Uint8Array(reader.result);
                    var length = bytes.byteLength;
                    for (var i = 0; i < length; i++) {
                        binary += String.fromCharCode(bytes[i]);
                    }
                    //pt.result  - readonly so assign content to another property
                    pt.content = binary;
                    $(pt).trigger('onload');
                };
                reader.readAsArrayBuffer(fileData);
            }
        }

        for(i = 0; i != files.length; ++i) {
            f = files[i];
            var reader = new FileReader();
            reader.onload = function (e) {
                // ADDED CODE
                if (!e) {
                    var data = reader.content;
                }
                else {
                    var data = e.target.result;
                    console.log(data);
                }
                // workbook = XLSX.read(data, {type: 'binary'});
                // business code
            };
            // reader.readAsBinaryString(f); //二进制
            reader.readAsText(f,'utf-8');
        }
    }
    //清空
    document.getElementById('toHandleFile').addEventListener('click', function(){
        this.value = null;
    });
    document.getElementById('toHandleFile').addEventListener('change', handleFile, false);

    /**-----------------------分页-end--------------------------------------*/

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        //页面加载之后执行
        console.log("$ionicView.afterEnter");
    });
});
