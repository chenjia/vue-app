angular.module('app.route').config(function ($stateProvider) {
    $stateProvider
        .state('zl.demo', {
            url: "/demo",
            template: '<ion-nav-view></ion-nav-view>',
            controller: function () {},
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        'app/demo/ctrl/demoCtrl.js',
                        'app/demo/service/demoHandler.js'
                    ]);
                }]
            }
        })
        .state('zl.demo.home', {
            url: "/home",
            templateUrl: function () {
                return 'app/demo/view/demo.html';
            },
            controller: 'demoCtrl',
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        'app/demo/ctrl/demoCtrl.js',
                        'app/demo/service/demoHandler.js'
                    ]);
                }]
            }
        })
        .state('zl.demo.date', {
            url: "/date",
            templateUrl: function () {
                return 'app/demo/view/date.html';
            },
            controller: 'dateCtrl',
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        'app/demo/ctrl/dateCtrl.js',
                        'aslib/jQuery/jQuery-2.1.4.min.js',
                        'app/base/directive/datepicker.js'
                    ]);
                }]
            }
        })
        .state('zl.demo.scroll', {
            url: "/scroll",
            templateUrl: function () {
                return 'app/demo/view/listscroll.html';
            },
            controller: 'listscrollCtrl',
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        'app/demo/ctrl/listscrollCtrl.js',
                    ]);
                }]
            }
        })
        .state('zl.demo.page', {
            url: "/page",
            templateUrl: function () {
                return 'app/demo/view/page.html';
            },
            controller: 'pageCtrl',
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        'app/demo/ctrl/pageCtrl.js',
                        'app/base/directive/page.js',
                        'app/base/directive/page/page.js'
                    ]);
                }]
            }
        })
        .state('zl.demo.acc', {
            url: "/acc",
            templateUrl: function () {
                return 'app/demo/view/acc.html';
            },
            controller: 'accCtrl',
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        'app/demo/ctrl/accCtrl.js',
                        'aslib/accordion/v-accordion.min.css',
                        'aslib/accordion/v-accordion.min.js'
                    ]);
                }]
            }
        })
        .state('zl.demo.file', {
            url: "/file",
            templateUrl: function () {
                return 'app/demo/view/file.html';
            },
            controller: 'fileCtrl',
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        'app/demo/ctrl/fileCtrl.js',
                    ]);
                }]
            }
        })
        .state('zl.demo.cal', {
            url: "/cal",
            templateUrl: function () {
                return 'app/demo/view/calendar.html';
            },
            controller: 'calendarCtrl',
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        'aslib/mobiscroll/j/css/mobiscroll.javascript.min.css',
                        'aslib/mobiscroll/j/js/mobiscroll.javascript.min.js',
                        'app/demo/ctrl/calendarCtrl.js',
                    ]);
                }]
            }
        })
    ;
});