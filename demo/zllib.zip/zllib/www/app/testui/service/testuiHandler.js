angular.module('app').factory('testuiHandler', function (utils) {
    return {
        testFunc: function (reqData, success, fail, start, end, mode) {
            success();
        }
    };
});
