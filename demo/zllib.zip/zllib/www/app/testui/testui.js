angular.module('app.route').config(function ($stateProvider) {
    $stateProvider
        .state('zl.pd.testui', {
            url: "/testui",
            // abstract: true,
            templateUrl: function () {
                return 'app/testui/view/testui.html';
            },
            controller: 'testuiCtrl',
            resolve: {
                load: ['$ocLazyLoad', function ($ocLazyLoad) {
                    return $ocLazyLoad.load([
                        'app/testui/ctrl/testuiCtrl.js',
                        'app/base/directive/headfoot.js',
                        'app/testui/service/testuiHandler.js'
                    ]);
                }]
            }
        })
        .state('zl.pd.testui.testuiSun', {
            url: "/testuiSun",
            // abstract: true,
            // templateUrl: function () {
            //     return 'app/testui/view/testuiSun.html';
            // },
            // controller: function () {}
            views: {
                'testuiSun': {
                    templateUrl: 'app/testui/view/testuiSun.html',
                    controller: function () {}
                }
            },
        })
    ;
});
