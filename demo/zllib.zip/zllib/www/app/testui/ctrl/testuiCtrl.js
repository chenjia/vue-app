angular.module('app').controller('testuiCtrl', function ($scope,$rootScope, utils, testuiHandler) {

    //页面绑定对象与页面交互
    $scope.vo = {};

    $rootScope.rootvo = {testRoot:'tttt'};

    utils.timeout(function () {
        $rootScope.rootvo.testRoot = 'wwwwwww';
    },1000*5);
    //页面业务控制类绑定对象
    $scope.vc = {
        testDebug:function () {
            var obj = {a:1, 'b':'foo', c:[false,'false',null, 'null', {d:{e:1.3e5,f:'1.3e5'}}]};
            var data =
                {
                    'first': {
                        'number': 1,
                        'text': 'Ya.'
                    },
                    'second': {
                        'number': 10,
                        'text': 'Da.'
                    },
                    "third": [{"number": 5, "text": "meh"},{"number": 6, "text": "beh"}]
                };
            // zzlogKeyValue(data);
            showJSON(data);
            // zzlogKeyValue(obj);
            // showJSON(obj);
        }
    };
    /**
     * 控制tab显示隐藏
     */
    // (function tabsFunc() {
    //     $scope.onDragUp = function(){
    //         $rootScope.tabsshow="hide";
    //     };
    //     $scope.onDragDown= function(){
    //         $rootScope.tabsshow="";
    //     };
    // })();

    // utils.ionic.ready(function () {
    //     $scope.onDragUp = function(){
    //         $rootScope.tabsshow="hide";
    //     };
    //     $scope.onDragDown= function(){
    //         $rootScope.tabsshow="";
    //     };
    // });

    $scope.vc.showTab = function () {
        utils.go('zl.pd.testui.testuiSun');
        // utils.timeout(function () {
        //     utils.$ionicScrollDelegate.$getByHandle('mScroll').resize();
        // },200);
        utils.resize('mScroll');
    };

    $scope.vc.alert = function () {
        // utils.$ionicLoading.show('hello');
        utils.$ionicPopup.alert({
            title: "提示",
            template: '',
            okText: "确定",
            okType: "btn_red"
        });
        //取消焦点事件
        document.activeElement.blur();
    };

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        //页面加载之后执行
        console.log("$ionicView.afterEnter");
    });

    $scope.onDragDown = function () {
        console.log('onDrag');
    };

});
