angular.module('app.route').factory('codeFactory', function () {
	return {
		testCode : "码表测试",

		cardCode:[
			{"code": "0", "desc": "身份证"}, {"code": "1", "desc": "军官证"}, {
			"code": "2",
			"desc": "士兵证"
		}, {"code": "3", "desc": "临时身份证"}, {"code": "4", "desc": "港澳居民来往大陆通行证"}, {
			"code": "5",
			"desc": "台湾居民来往大陆通行证"
		}, {"code": "6", "desc": "护照"}, {"code": "7", "desc": "出生证明"}, {"code": "8", "desc": "户口本"}, {
			"code": "9",
			"desc": "外国人永久居留证"
		}, {"code": "99", "desc": "其他"}
		]
	}
	;
});