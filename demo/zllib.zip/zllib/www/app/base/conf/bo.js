angular.module('app.route').constant("bo", {
    "boTest": {
        "hello": null
    },
    "boLogin": {
        "username": null,
        "password": null,
    }
});
