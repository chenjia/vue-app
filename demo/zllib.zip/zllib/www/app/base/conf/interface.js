angular.module('app.route').factory('htag', function () {
    var MODE_GET = "GET";
    function URL(url) {
        return globalConfig.rootUrl + url;
    }

    var SERVICE_LOGIN = "loginRestful.do";
    var SERVICE_GET_CERT_CODE = "portal/loadIdentifyCodeRestful.do";
    var SERVICE_IN_ENTRY = "inEntryRestful.do";
    var SERVICE_LOGOUT = "avtivity/logout";
    var SERVICE_TEST_GY = "callServiceByMobile.do";

    var htag = {
        htag_login: {url: URL(SERVICE_LOGIN)},
        htag_getCertCode: {url: URL(SERVICE_GET_CERT_CODE)},
        htag_inEntry: {url: URL(SERVICE_IN_ENTRY)},
        htag_logout: {url: URL(SERVICE_LOGOUT)},
        htag_test_get: {url: URL(SERVICE_LOGIN),mode:MODE_GET},
        htag_test_gy: {url: URL(SERVICE_TEST_GY),smid:'6666'},//for 工银
    };

    return htag;
});
