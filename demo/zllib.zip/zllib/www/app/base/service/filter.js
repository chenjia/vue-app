angular.module('app.route').filter('optionFilter', function () {
    return function (val) {
        if (val == 'pay') {
            return "交费期间";
        } else if (val == 'insure') {
            return "保险期间";
        } else if (val == 'pay_freq') {
            return "";
        } else if (val == 'draw_freq') {
            return "年金給付週期";
        } else if (val == 'draw_age') {
            return "領取年齡";
        } else if (val == 'rank') {
            return "保額";
        } else if (val == 'draw') {
            return "保證期間";
        } else if (val == '1') {
            return "檔次";
        } else if (val == 'amount') {
            return "保額";
        } else if (val == 'premium') {
            return "年交保费";
        } else if (val == 'quantity') {
            return "份数";
        } else if (val == '5') {
            return "檔次";
        } else if (val == '6') {
            return "檔次";
        } else if (val == '7') {
            return "檔次";
        }
    };
}).filter('shortFilter', function () {
    return function (value, length) {
        length = length || 12;
        if (value && value.length > length) {
            value = value.substr(0, length) + '...';
        }
        return value;
    };
}).filter('sexFilter', function () {
    return function (value, length) {
        return value == '1' ? '男' : '女';
    };
});