angular.module('app.route').factory('allHandler', function (utils) {
    return {
        testFunc: function (reqData, callback, mode) {
            callback();
        }
    };
});
