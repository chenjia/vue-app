globalConfig = {
    // rootUrl:'http://localhost:8080/sunshine_jzyx_server/',
    rootUrl: 'http://10.7.204.23/sfss-web/',
    // rootUrl: 'http://192.168.1.111:8080/ssm_server/',
    // plat:'WX',
    timeout:1000 * 20,//默认是3000毫秒 ps: 1秒=1000毫秒
    debug:true,
    // mouse:true   //开启指针
    //removeIf(zzdebug)
    // mode:'debug',
    // key:'ed26d4cd99aa11e5b8a4c89cdc776729'
    //endRemoveIf(zzdebug)
    /**/
};

if(typeof zua !== "undefined"){globalConfig=angular.extend(zua.info,globalConfig);}

function http_post_pre(urlStr,data) {
    // console.log(urlStr+data);
    var illegalChar = ['&', '\'', '"', '\\n', '\\t', '\\s', '<', '>', '\\', '../','script','%'];
    for(var key in data){
        var content=data[key]+'';
        for (var i = 0; i < illegalChar.length; i++) {
            if (content.indexOf(illegalChar[i]) > -1) {
                // utils.ui.alert({msg : '本次提交存在可以疑参数'});
                alert('本次提交存在可以疑参数');
                var rp = {
                    success: function(fun){
                        //fun('',1);
                        return rp;
                    },
                    error: function(fun){
                        // console.log(fun);
                        fun();
                        return rp;
                        },
                    then: function(fun){
                        // console.log(fun);
                        // fun();
                        return rp;
                    }
                };
                return rp;
            }
        }
    }
    return true;
}

(function (document){
    angular.module('app.route',[]);
    angular.module('app', ['ionic', 'oc.lazyLoad', 'app.route']);
    angular.module('app').run(function ($ionicPlatform) {
        $ionicPlatform.ready(function() {
            if (window.cordova && window.cordova.plugins.Keyboard) {
                // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
                // for form inputs)
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(false);
                // Don't remove this line unless you know what you are doing. It stops the viewport
                // from snapping when text inputs are focused. Ionic handles this internally for
                // a much nicer keyboard experience.
                cordova.plugins.Keyboard.disableScroll(true);
            }
            if (window.StatusBar) {
                // StatusBar.styleDefault();
                StatusBar.backgroundColorByHexString("#408fd3");
                StatusBar.overlaysWebView(false);
            }
        });
    });

    angular.module('app.route').config(function ($urlRouterProvider,$ionicConfigProvider) {
        $urlRouterProvider.otherwise('/zl/test');

        $ionicConfigProvider.views.swipeBackEnabled(false);
        $ionicConfigProvider.views.maxCache(6);//页面缓存数
        $ionicConfigProvider.views.transition('none');
        $ionicConfigProvider.backButton.text("");
        $ionicConfigProvider.backButton.previousTitleText(false);
        if(globalConfig.mouse) {$ionicConfigProvider.scrolling.jsScrolling(false);}
    });

    var routerList = [
        //removeIf(zztest)
        'app/testui/testui.js',
        'app/demo/demo.js',
        //endRemoveIf(zztest)
        'app/test/test.js',
    ];
    var str = '';routerList.unshift('app/basic/root/zlpd.js');routerList.push('app/basic/root/service/zutils.js');routerList.push('lib/base/utils.js');
    //removeIf(zzdebug)
    var libList = [
        // 'app/basic/root/service/zutils.js',//IE环境下需要挪到utils之前加载
        // 'lib/base/base64.min.js',
        'lib/ocLazyLoad/ocLazyLoad.min.js',
        'lib/base/util/interceptor/auth.js',
        'lib/base/util/cookie/cookie.js',
        'lib/base/app.js',
        // 'lib/base/util/ui/ui.js',
        'lib/base/util/uuid/uuid.js',
        'lib/base/util/math/math.js',
        // 'lib/base/util/validate/regex.js',
        'lib/base/util/locals/locals.js',
        'lib/base/util/date/date.js',
        'lib/base/util/http/http.js',
        'lib/base/utils.js',
        'lib/base/util/security/des.js'
    ];
    routerList = routerList.concat(libList);
    //endRemoveIf(zzdebug)
    routerList.forEach(function (router) {str += '<script src="' + router + '"></script>';});document.write(str);
}(document));

//需要延后注入到util中，则需要在此加载，且注入入口为zutils.init
var libListOfZl = [
    'app/base/conf/interface.js',
    'app/base/conf/bo.js',
    'app/base/conf/code.js',
    'app/basic/root/service/check.js',
    //removeIf(zzdebug)
    // 'app/basic/root/service/zutils.js',//IE环境下需要挪到utils之前加载
    // 'lib/ocLazyLoad/ocLazyLoad.min.js',
    // 'lib/base/util/interceptor/auth.js',
    // 'lib/base/util/cookie/cookie.js',
    // 'lib/base/app.js',
    // 'lib/base/util/ui/ui.js',
    // 'lib/base/util/uuid/uuid.js',
    // 'lib/base/util/math/math.js',
    // 'lib/base/util/validate/regex.js',
    // 'lib/base/util/locals/locals.js',
    // 'lib/base/util/date/date.js',
    // 'lib/base/util/http/http.js',
    // 'lib/base/utils.js',
    //endRemoveIf(zzdebug)
    'app/base/service/filter.js',
];

//延迟加载首屏不需要，但其他页面需要用到的第三方js库
var lazyloadlib=[
    'aslib/jQuery/jQuery-2.1.4.min.js',
];