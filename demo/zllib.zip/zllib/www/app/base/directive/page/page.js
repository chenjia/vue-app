angular.module('app').directive('page1',function(utils) {
    var utility = {
        //转换为int
        convertInt: function (i) {
            if (typeof i === 'number') {
                return i;
            } else {
                var j = parseInt(i);
                if (!isNaN(j)) {
                    return j;
                } else {
                    throw new Error("convertInt Type Error.  Type is " + typeof i + ', value = ' + i);
                }
            }
        },
        //返回是否小数
        isDecimal: function (i) {
            return parseInt(i) !== i;
        }
    };

    //计算最大分页数
    function calLastPageNum(total, pageSize) {
        total = utility.convertInt(total);
        pageSize = utility.convertInt(pageSize);
        var i = total / pageSize;
        return utility.isDecimal(i) ? parseInt(i) + 1 : i;
    }

	return {
		restrict: 'AE',
		replace: true,
		require: "ngModel",
		scope: {
			// page: '=ngModel', //传递过来的分页信息
			// changePage: '=' //回调方法
            ngModel:'=',//当前页码
            // pageModel:'=',//内置
            totalItems:'=',//一共多少条数据
            itemsPerPage:'=',//每页显示多少条数据
            ngChange:'=',//查询回调方法
		},
		templateUrl: 'app/base/directive/page/page.html',
		link: function(scope, element, attrs, ctrls) {
			
			//单独显示(注:5代表切换页面单独显示的1~5)
			//scope.singlePageList = new Array(5);
			//scope.singlePageListMiddle = scope.singlePageList.length % 2 === 0 ? scope.singlePageList.length / 2 : (scope.singlePageList.length + 1) / 2;
			//切换页面
			scope.pageNum =calLastPageNum(scope.totalItems,scope.itemsPerPage);
			scope.changePageClick = function(state) {
				var changePageNo = null;
				if(state === 'start') {
					changePageNo = 1;
				} else if(state === 'up') {
					changePageNo = parseInt(scope.ngModel) > 1 ? parseInt(scope.ngModel) - 1 : 1;
				} else if(state === 'down') {
					changePageNo = parseInt(scope.ngModel) < parseInt(scope.pageNum) ? parseInt(scope.ngModel) + 1 : parseInt(scope.pageNum);
				} else if(state === 'end') {
					changePageNo = parseInt(scope.pageNum);
				} else if(state === 'go') {
					if(parseInt(scope.goPage) <= parseInt(scope.pageNum)) {
						changePageNo = parseInt(scope.goPage);
					} else {
						// utils.JAlert.singleRuleHint('请正确输入正确页码');
                        console.log('请正确输入正确页码');
						return;
					}
				} else {
					//eg:点击的1，传递过去的也是1
					if(state <= scope.page.pageNum) {
						changePageNo = state;
					}
				}
                if(scope.ngModel==changePageNo){
					return;
                }
                // console.log(scope.ngModel);
                // console.log(changePageNo);
				scope.ngModel = changePageNo;
                // scope.$apply();
				// scope.ngChange(state,changePageNo);
                scope.ngChange(changePageNo);
			}
		}
	};
});