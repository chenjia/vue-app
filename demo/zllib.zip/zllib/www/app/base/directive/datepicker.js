angular.module('app').directive('datepicker', function(utils) {
	return {
		restrict: 'AE',
		replace: true,
		scope: {
			ngModel: '=',
			ngDisabled: '=',
			start:'=',
			end:'=',
            change:'&'
		},
		template:function (element, attrs) {
			var pc = '<input type="text"/>';
			var mobile = '<input type="text" disabled=false style="background:none;display:inline;margin-left: 0px !important;z-index: inherit;"/>';

			var uimode = utils.uimode(attrs);
			if(typeof zua !== "undefined"&&zua.platform()=='iPad'){
				return mobile;
			}
			if(uimode === 'mobile'){return mobile;}
			else if(uimode === 'pc') {return pc;}
			return mobile;
		},
		// template: '<input type="text"/>',
		link: function(scope, element, attrs, ctrls) {
			var uimode = utils.uimode(attrs);
            if(typeof zua !== "undefined"&&zua.platform()=='iPad'){
                uimode='mobile';
            }
			if(uimode === "pc") {
				utils.ocload.load([
					// 'app/base/lib/jQuery/jQuery-2.1.4.min.js',
					'aslib/My97DatePicker/WdatePicker.js',
				]).then(function() {
					if(scope.ngModel)
						scope.ngModel = utils.date.dateFormat(new Date(scope.ngModel), 'yyyy-MM-dd');
					var opt = {
						onpicking: function(dp) {
							scope.ngModel = dp.cal.getNewDateStr();
							scope.$apply();
						},
						//取消按钮
						onclearing: function() {
							scope.ngModel = "";
							scope.$apply();
							return true;
						},
						dateFmt: attrs.format || 'yyyy-MM-dd',
						minDate: attrs.futureTime ? new Date() : undefined,
						maxDate: attrs.maxDate ? attrs.maxDate : "2099-01-01"
					};
					if(attrs.maxDate) {
						if(attrs.maxDate === "now") {
							// opt.maxDate = '#F{$dp.$D(\''+utils.date.dateFormat(new Date(), 'yyyy-MM-dd')+'\',{d:0});}';
                            // new Date();
						} else {
							opt.maxDate = '#F{$dp.$D(\''+attrs.maxDate+'\',{d:0});}';
						}
					}
					if(attrs.minDate) {
						if(attrs.minDate === "now") {
							// opt.minDate = '#F{$dp.$D(\''+utils.date.dateFormat(new Date(), 'yyyy-MM-dd')+'\',{d:0});}';
                            // new Date();
						} else {
							opt.minDate = '#F{$dp.$D(\''+attrs.minDate+'\',{d:0});}';
						}

					}
					element.on("click", function(event) {
						WdatePicker(opt);
					});
				});
			} else {
				/**
				 * attrs属性标识: width height textAlign
				 * format:日期控件显示格式,可中文
				 * isIcon:是否展示日历图标在控件后面
				 * iconColor:日历图标颜色
				 * isSwitch:是否使用左右点击控件(不允许和日历图标同时使用)
				 * switchColor:点击控件背景颜色
				 * disableDate:是否禁用日期控件(一般在使用点击控件时才选择是否禁用)
				 * calDays:左右点击加减的天数
				 */
				utils.ocload.load([
					'aslib/jQuery/jQuery-2.1.4.min.js',
					'aslib/mobiscroll/css/mobiscroll.datetime.min.css',
					'aslib/mobiscroll/js/mobiscroll.datetime.min.js',
				]).then(function() {
					var inElement = $(element[0]);
					if(attrs.width) {
						inElement.css('width', attrs.width);
					}
					if(attrs.padding) {
						inElement.css('padding', attrs.padding);
					}
					if(attrs.height) {
						inElement.css('height', attrs.height);
					}
					// if($rootScope.phone) {
					// 	inElement.addClass('text-right');
					// }
					if(attrs.paddingRight) {
						inElement.css('padding-right', attrs.paddingRight);
					} else if(attrs.paddingLeft) {
						inElement.css('padding-left', "0px");
					} else {
						inElement.css('padding-right', "50px");
					}
					if(attrs.color) {
						inElement.css('color', attrs.color);
					}
					if(attrs.fontSize) {
						inElement.css('font-size', attrs.fontSize);
					} else {
						inElement.css('font-size', "");
					}
					if(attrs.textAlign) {
						inElement.css('text-align', attrs.textAlign);
					} else {
						inElement.css('text-align', "right");
					}

                    if(attrs.isIcon){
                        var inputStyle = attrs.inputStyle || '-25px';
                        inElement.css('margin-right',inputStyle);
                        inElement.css('padding-right','40px');
                        $('<i class="icon ion-calendar" style="float: right;color: #3399ff;margin: 0px;font-size: 1.3em;padding-right: 10px;padding-top: '+(attrs.pt?attrs.pt:0)+'"></i>').insertAfter(inElement);
                    }

                    if(attrs.isSwitch){
                        var par = inElement.parent('div');
                        var color = attrs.switchColor || '#337ab7';
                        if(attrs.isLine){
                            $(par).css({'padding':'10px 0px','background-color':'white','line-height':'16px','font-size':'16px','border-top':'1px solid #e3e3e3','border-bottom':'1px solid #e3e3e3'});
                            inElement.css({'padding':'10px 0','width':'64%','color':'#3399ff'});
                            var faLeft = $('<i class="fa fa-angle-left" aria-hidden="true" style="color:#cccccc;padding:10px 0;margin:-10px 0;text-align:center;width:18%;"></i>').insertBefore(inElement);
                            var faRight = $('<i class="fa fa-angle-right" aria-hidden="true" style="color:#cccccc;padding:10px 0;margin:-10px 0;text-align:center;width:18%;"></i>').insertAfter(inElement);
                        } else {
                            $(par).css({'padding':'10px 0px','background-color':color,'border-radius':'5px'});
                            inElement.css({'padding':'10px 0','width':'64%','color':'white'});
                            var faLeft = $('<i class="fa fa-angle-left" aria-hidden="true" style="color:white;padding:10px 0;margin:-10px 0;text-align:center;width:18%;"></i>').insertBefore(inElement);
                            var faRight = $('<i class="fa fa-angle-right" aria-hidden="true" style="color:white;padding:10px 0;margin:-10px 0;text-align:center;width:18%;"></i>').insertAfter(inElement);
                        }
                        function fillZero(num){
                            if(num<10){
                                num = '0'+num;
                            }
                            return ''+num;
                        }
                        function calDate(type,calDays){
                            var year = parseInt(scope.ngModel.substr(0,4));
                            var month,date,temp;
                            if(attrs.format.indexOf('mm')!=-1){
                                month = parseInt(scope.ngModel.substr(5,2));
                            }
                            if(attrs.format.indexOf('dd')!=-1){
                                date = parseInt(scope.ngModel.substr(8,2));
                            }
                            if(date){
                                var cDate = new Date(year,month-1,date);
                                var rDate;
                                if(type=='l'){
                                    rDate = new Date(cDate.valueOf() - calDays * 86400000);
                                } else {
                                    rDate = new Date(cDate.valueOf() + calDays * 86400000);
                                }
                                year = rDate.getFullYear();
                                month = rDate.getMonth() + 1;
                                date = rDate.getDate();
                                temp = attrs.format.replace('yyyy',year).replace('mm',fillZero(month)).replace('dd',fillZero(date));
                            } else if(month){
                                if(type=='l'){
                                    if(month==1){
                                        year = year - 1;
                                        month = 12;
                                    } else {
                                        month = month - 1;
                                    }
                                } else {
                                    if(month==12){
                                        year = year + 1;
                                        month = 1;
                                    } else {
                                        month = month + 1;
                                    }
                                }
                                temp = attrs.format.replace('yyyy',year).replace('mm',fillZero(month));
                            } else {
                                if(type=='l'){
                                    year = year - 1;
                                } else {
                                    year = year + 1
                                }
                                temp = attrs.format.replace('yyyy',year);
                            }
                            scope.year = year;
                            scope.month = fillZero(month);
                            scope.date = fillZero(date);
                            scope.ngModel = temp;
                            scope.$apply();
                            utils.timeout(function() {
                                scope.change();
                            }, 50);
                        }
                        var calDays = attrs.calDays || 1;
                        faLeft.click(function(){
                            calDate('l',calDays);
                        });
                        faRight.click(function(){
                            calDate('r',calDays);
                        });

                        scope.dateChange = function() {
                            utils.timeout(function() {
                                scope.year = scope.ngModel.substr(0,4);
                                if(attrs.format.indexOf('mm')!=-1){
                                    scope.month = scope.ngModel.substr(5,2);
                                }
                                if(attrs.format.indexOf('dd')!=-1){
                                    scope.date = scope.ngModel.substr(8,2);
                                }
                                utils.timeout(function() {
                                    scope.change();
                                }, 50);
                            }, 50);
                        }
                    }

					if(!attrs.disableDate){
						function calMaxMinDate() {
							if(attrs.end||attrs.start){
								if(scope.start)
								{
                                    var str = scope.start;
                                    if(str){
                                        var y = parseInt(str.substr(0,4));
                                        var m=1,d=1;
                                        if(fmtStr.indexOf('mm')!=-1){
                                            m = parseInt(str.substr(5,2));
                                        }
                                        if(fmtStr.indexOf('dd')!=-1){
                                            d = parseInt(str.substr(8,2));
                                        }
										inElement.mobiscroll('option',{
											minDate: new Date(y,m-1,d)
										});
                                    }
								}else{
                                    inElement.mobiscroll('option',{
                                        minDate: null
                                    });
								}
								if(scope.end)
								{
                                    var str = scope.end;
                                    if(str){
                                        var y = parseInt(str.substr(0,4));
                                        var m=1,d=1;
                                        if(fmtStr.indexOf('mm')!=-1){
                                            m = parseInt(str.substr(5,2));
                                        }
                                        if(fmtStr.indexOf('dd')!=-1){
                                            d = parseInt(str.substr(8,2));
                                        }
										inElement.mobiscroll('option',{
											maxDate: new Date(y,m-1,d)
										});
                                    }
								}else{
                                    inElement.mobiscroll('option',{
                                    	maxDate: new Date(2100, 1, 1)
                                    });
								}
								if(!scope.start&&!scope.end)
								{
                                    if(attrs.end){
                                        inElement.mobiscroll('option',{
                                            maxDate: new Date(2100, 1, 1)
                                        });
                                    } else {
                                        inElement.mobiscroll('option',{
                                            minDate: new Date(1899, 12, 1)
                                        });
                                    }
								}
							}
						}

						var fmtStr = attrs.format || 'yy-mm-dd';//yyyy-mm-dd HH:mm:ss
						if(fmtStr.indexOf('yyyy')!=-1) {
							fmtStr = fmtStr.replace('yyyy','yy');
						}
						var dateType = 'ymd';
						if(fmtStr.indexOf('dd')!=-1&&fmtStr.indexOf('HH')!=-1){
							dateType = 'ymdhm';
							fmtStr = fmtStr.substr(0,10);
						} else if(fmtStr.indexOf('HH')!=-1) {
							dateType = 'hm';
						}
						var options = {
							theme: 'android-holo-light',
							lang: 'zh',
							dateFormat: fmtStr,
							onSelect: function(valueText, inst) {
								scope.ngModel = valueText;
								scope.$apply();
							},
							onBeforeShow: function(inst){
								calMaxMinDate();
								if(fmtStr.indexOf('dd')==-1&&fmtStr.indexOf('mm')>-1){ //去掉'日'选项滚轮
									inst.settings.wheels[0].length>2?inst.settings.wheels[0].pop():null;
								} else if(fmtStr.indexOf('mm')==-1){ //去掉'日,月'选项滚轮
									var terms = inst.settings.wheels[0].length;
									for(terms; terms>1; terms--){
										inst.settings.wheels[0].pop();
									}
								}
							},
							minDate: attrs.futureDay ? new Date() : new Date(1899, 12, 1),
							maxDate: attrs.birthday ? new Date() : new Date(2100, 1, 1)
						};
						if(scope.ngModel){
							options.defaultValue = utils.date.toDate(scope.ngModel);
                            if(/^\d{4}-\d{2}$/.test(scope.ngModel)==true)
                            {
                                options.defaultValue = utils.date.toDate(scope.ngModel+"-01");
                            }
						}
						// inElement.mobiscroll().date(options);

						if(dateType=='ymd'){
							inElement.mobiscroll().date(options);
						} else if(dateType=='ymdhm') {
							inElement.mobiscroll().datetime(options);
						} else {
							delete options.minDate;
							delete options.maxDate;
							inElement.mobiscroll().time(options);
						}
					} else {
						inElement.attr('disabled','disabled');
					}
				});

			}
		}
	};
});