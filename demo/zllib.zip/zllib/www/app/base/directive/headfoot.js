angular.module('app').directive('headfoot', ['utils', function(utils) {
	return {
		restrict: 'AE',
		replace: true,
		// require: '^ngModel',
		scope: {
			ngModel: '='
		},
		template: '',
		// templateUrl: 'app/basic/home/view/layout.html',
		link: function(scope, element, attr, ctrl) {
			utils.ocload.load([
				'aslib/jQuery/jQuery-2.1.4.min.js',
			]).then(function() {
				element = $(element[0]);
				// scope.vo = {
				// 	test : 'test hello'
				// };
				// element.parent().append($('#footer'));
				// var ttt= $('#footer');
				var header = '<div ng-include="\'app/basic/home/view/header.html\'">header</div>';
				var footer = '<div ng-include="\'app/basic/home/view/footer.html\'"></div>';
				// element.parent().append('<div>在开头追加文本<div>');
				element.parent().prepend(utils.$compile(header)(scope));
				element.parent().append(utils.$compile(footer)(scope));
			});
		}
	};
}]);