angular.module('app').directive('page', function(utils) {
	return { 
		restrict:'EA',
		replace:true,
		scope: {
			ngModel:'=',//当前页码
            pageModel:'=',//内置
			totalItems:'=',//一共多少条数据
			itemsPerPage:'=',//每页显示多少条数据
			ngChange:'=',//查询回调方法
		},
		template:'<div id="pageId" class="m-pagination"></div>',
		link:function(scope, element, attrs, ctrls){
            utils.ocload.load([
                'aslib/jQuery/jQuery-2.1.4.min.js',
            ]).then(function () {
                utils.ocload.load([
                    'aslib/pagination/mricode.pagination.css',
                    'aslib/pagination/mricode.pagination.min.js'
                ]).then(function() {
                    if ($("#pageId").pagination()) {
                        $("#pageId").pagination('destroy');
                    }
                    // console.log(scope.ngModel);
                    scope.pageModel = angular.copy(scope.ngModel-1);
                    $("#pageId").pagination({
                        pageIndex: scope.pageModel,
                        pageSize: scope.itemsPerPage,
                        total: scope.totalItems,
                        debug: false,
                        firstBtnText: '首页',
                        lastBtnText: '尾页',
                        prevBtnText: '上页',
                        nextBtnText: '下页',
                        showInfo: false,
                        showJump: true,
                        pageBtnCount:9,
                        showPageSizes: false,
                        // infoFormat: '{start} ~ {end}条，共{total}条',
                        pageElementSort: ['$page', '$size', '$jump', '$info']
                    });
                    $("#pageId").on("pageClicked", function (event, data) {
                        // console.log('EventName = pageClicked , pageIndex = ' + data.pageIndex);
                        scope.ngModel = data.pageIndex+1;
                        scope.pageModel = data.pageIndex;
                        scope.$apply();
                        scope.ngChange(data.pageIndex);
                    }).on('jumpClicked', function (event, data) {
                        // console.log('EventName = jumpClicked , pageIndex = ' + data.pageIndex);
                        scope.ngModel = data.pageIndex+1;
                        scope.pageModel = data.pageIndex;
                        scope.$apply();
                        scope.ngChange(data.pageIndex);
                    }).on('pageSizeChanged', function (event, data) {
                        // console.log('EventName = pageSizeChanged , pageIndex = ' + data.pageIndex);
                        scope.ngModel = data.pageIndex+1;
                        scope.pageModel = data.pageIndex;
                        scope.$apply();
                        scope.ngChange(data.pageIndex);
                    });

                    scope.$watch('pageModel',function(value,oldValue){
                        console.log('pageModel '+value);
                        $("#pageId").pagination('setPageIndex', value);
                        $("#pageId").pagination('setPageSize', scope.itemsPerPage);
                        $("#pageId").pagination('render', scope.totalItems);
                    });

                    scope.$watch('ngModel',function(value,oldValue){
                        console.log('ngModel '+ value);
                        scope.pageModel = value-1;
                    });
                });
            });
		}
    };
});