1.aslib
2.两个版本
3.日志
4.异常捕获
5.oclazyload

/zl

/login

#### 源码修改

1.

```javascript
var isIE = function() {
    return !!(window.ActiveXObject || "ActiveXObject" in window);
};
```

2.

```javascript
keyboardHeight: !isIE() === true ? M() : 0,
```

```javascript
 (!s || d) && (!isIE()) && (!c && (e.Platform.isIOS() || e.Platform.isFullScreen || u) && e.requestAnimationFrame(function() {
                        t = Math.max(0, Math.min(i.__originalContainerHeight, i.__originalContainerHeight - (o.detail.keyboardHeight - 43))), r.style.height = t + "px", r.classList.add("keyboard-up"), i.resize()
                    }), i.isShrunkForKeyboard = !0), n = !isIE() === true ? o.detail.keyboardHeight : 0, o.detail.isElementUnderKeyboard
```



```javascript
function w(e, t) {
                return t && t.$$state && t.$$state.self.canSwipeBack === !1 ? !1 : !e || "false" !== e.attr("can-swipe-back")
            }
```

改为了

```
function w(e, t) {
                return false
            }
```

```javascript
swipeBackEnabled: !1,
```

```
&& C.initSwipeBack()
```

