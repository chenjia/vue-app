## AngularJS 全局 API

- element
- bootstrap
- copy
- extend
- merge
- equals
- forEach
- noop
- bind
- toJson
- fromJson
- identity
- isUndefined
- isDefined
- isString
- isFunction
- isObject
- isNumber
- isElement
- isArray
- version
- isDate
- lowercase
- uppercase
- module

## angular.forEach

forEach(obj, iterator)
遍历obj(可以是对象，也可以是数组)对象，并依次调用iterator(value, key, obj)函数。
其中iterator函数，接收的三个参数分别为

- value: 对象的属性(数组元素)
- key: 对象的属性名(数组的索引)
- obj: 数组(对象)本身

例子:

```
var list = ['小明', '小毛', '小周', '小蕾'];
angular.forEach(list, function (val, key) {
    console.log(key + '号同学:' + val);
})

var obj = {
    name: '吴登广',
    age: '21',
    title: 'worker'
}

angular.forEach(obj, function (val, key) {
    console.log(key + ':' + val);
})
```

效果:![img](bVxQdd.png)

## angular.module

这个方法大家应该都很熟悉了
module(name, requires)，name为模块名，requires(可选)为依赖的模块，当有依赖的模块数组的时候，表示注册一个模块，没有时为引用一个模块。
例子:

```
angular.module('main', []);

console.log(angular.module('main'));
```

效果:![img](bVxQe6.png)

## angular.element

这个方法是用来操作DOM的，一般在指令里面使用。在引入了jquery的情况下，使用方法和jquery几乎一样，相当于一个语法糖。

```
var ele = angular.element('h1');
console.log(ele.html());

```

在没有引入jquery的情况下，使用的其实是jqLite(angular自己封装的类似于jquery的一个东西)，使用方法也类似，只不过不支持一些jquery的选择器。

```
var ele = angular.element(document.getElementsByTagName('h1')[0]);
console.log(ele.html());

```

至于用jqLite获取到的封装过后的DOM节点和jquery的有点不太一样，这里可以参考[一篇文章](http://www.jb51.net/article/59544.htm)。

addClass()-为每个匹配的元素添加指定的样式类名
after()-在匹配元素集合中的每个元素后面插入参数所指定的内容，作为其兄弟节点
append()-在每个匹配元素里面的末尾处插入参数内容
attr() - 获取匹配的元素集合中的第一个元素的属性的值
bind() - 为一个元素绑定一个事件处理程序
children() - 获得匹配元素集合中每个元素的子元素，选择器选择性筛选
clone()-创建一个匹配的元素集合的深度拷贝副本
contents()-获得匹配元素集合中每个元素的子元素，包括文字和注释节点
css() - 获取匹配元素集合中的第一个元素的样式属性的值
data()-在匹配元素上存储任意相关数据
detach()-从DOM中去掉所有匹配的元素
empty()-从DOM中移除集合中匹配元素的所有子节点
eq()-减少匹配元素的集合为指定的索引的哪一个元素
find() - 通过一个选择器，jQuery对象，或元素过滤，得到当前匹配的元素集合中每个元素的后代
hasClass()-确定任何一个匹配元素是否有被分配给定的（样式）类
html()-获取集合中第一个匹配元素的HTML内容
next() - 取得匹配的元素集合中每一个元素紧邻的后面同辈元素的元素集合。如果提供一个选择器，那么只有紧跟着的兄弟元素满足选择器时，才会返回此元素
on() - 在选定的元素上绑定一个或多个事件处理函数
off() - 移除一个事件处理函数
one() - 为元素的事件添加处理函数。处理函数在每个元素上每种事件类型最多执行一次
parent() - 取得匹配元素集合中，每个元素的父元素，可以提供一个可选的选择器
prepend()-将参数内容插入到每个匹配元素的前面（元素内部）
prop()-获取匹配的元素集中第一个元素的属性（property）值
ready()-当DOM准备就绪时，指定一个函数来执行
remove()-将匹配元素集合从DOM中删除。（同时移除元素上的事件及 jQuery 数据。）
removeAttr()-为匹配的元素集合中的每个元素中移除一个属性（attribute）
removeClass()-移除集合中每个匹配元素上一个，多个或全部样式
removeData()-在元素上移除绑定的数据
replaceWith()-用提供的内容替换集合中所有匹配的元素并且返回被删除元素的集合
text()-得到匹配元素集合中每个元素的合并文本，包括他们的后代
toggleClass()-在匹配的元素集合中的每个元素上添加或删除一个或多个样式类,取决于这个样式类是否存在或值切换属性。即：如果存在（不存在）就删除（添加）一个类
triggerHandler() -为一个事件执行附加到元素的所有处理程序
unbind() - 从元素上删除一个以前附加事件处理程序
val()-获取匹配的元素集合中第一个元素的当前值
wrap()-在每个匹配的元素外层包上一个html元素

## angular.bootstrap

这个函数不太常用。如果你不想使用ng-app指令来启动angular应用的话，可以用angular.bootstrap()来启动

```
angular.element(document).ready(function() {
    angular.bootstrap(document, []);
});
```

需要依赖的模块数组做为参数。

## angular.toJson

其实就是调用JSON.stringify()方法将一个对象或数组，格式化为JSON字符串。

## angular.fromJSON

就是调用JSON.parse()方法将一个JSON字符串转换为一个对象例子:

```
var user = {
    name: 'Jax2000',
    age: 21,
    title: 'worker'
}
user = angular.toJson(user)
console.log(user);
user = angular.fromJson(user);
console.log(user);

```

效果:![img](bVxQz7.png)

## angular.copy

copy(source, destination)
深复制一个对象或者数组，这是一个非常实用的方法，熟悉js的人都应该知道，js中 = 操作符，实际上复制的是指针，所以前后两个变量指向的还是内存中的同一个对象，所以我们在其中一个变量上操作该对象时，对另外一个变量也会生效，有时候我们并不希望出现这种情况。然后angular.copy方法就是深复制，会在内存中再生成一个对象，两个变量就可以独立，相互不产生影响。
接收一个必须参数source，和一个可选参数destination

```
var user1 = {
    name: 'wudengguang',
    age: 21,
    title: 'worker'
}
var user2 = user1;
var user3 = angular.copy(user1);
var user4 = {};

// 注意这个user4必须是一个对象或者数组
angular.copy(user1, user4);
user1.name = 'liulei';
console.log('user1:' + user1.name);
console.log('user2:' + user2.name);
console.log('user3:' + user3.name);
console.log('user4:' + user4.name);

```

效果:![img](bVxQdd.png)

可以看到改变user1的name字段之后，浅复制的user2受到了影响，而深复制的user3和user4没有受到影响

## angular.extend

extend(destination, src1, src2...)这个方法是用来扩展对象的，destination为要扩展的对象，会将后面的对象的属性全部复制到destination中，不过是浅复制

```
var user1 = {
    name: 'Jax2000',
    age: 21,
}

var user2 = {
    age: 22,
    skill: {}
}

var dst = {};

angular.extend(dst, user1, user2);

console.log(dst);

console.log(dst.skill === user2.skill);
```

![img](bVxQKs.png)

## angular. merge

这个方法和extend方法是一样的，也是用来扩展目标对象的，不过用的是深复制

```
var user1 = {
    name: 'Jax2000',
    age: 21,
}

var user2 = {
    age: 22,
    skill: {}
}

var dst = {};

angular.merge(dst, user1, user2);

console.log(dst);

console.log(dst.skill === user2.skill);
```

![img](bVxQKA.png)

merge和extend常用于获取存储在服务端的用户设置，然后需要和本地的结合的这一类案例。如果对于copy,extend,merge的区别还不是很了解的话，可以看[这篇文章](http://davidcai.github.io/blog/posts/copy-vs-extend-vs-merge/)。

## angular.equals

equals(o1, o2)见文知意，判断两个对象或者值是否相等，其中对象只要是属性都想同即可。

```
var user1 = {
    name: 'Jax2000',
    age: 21,
}

var user2 = {
    age: 21,
    name: 'Jax2000'
}

console.log(angular.equals(user1, user2));


```

结果是true

## angular.noop

这个方法直接看源代码就知道了

```
function noop() {}

```

我也不是很清楚，这个东西干嘛的，可能是有些函数需要回调函数做为参数，在没有时调用的吧，官方的文档案例:

```
function foo(callback) {
    var result = calculateResult();
    (callback || angular.noop)(result);
}
```

## angular.bind

这个方法就是返回一个有特定作用域的函数对象
angular.bind(self, fn, args)
self: 函数的作用域
fn: 需要改变作用域的函数
args: 需要传递给该函数的参数数组

```
var user1 = {
    name: 'Jax',
    age: 21,
}

var user2 = {
    age: 21,
    name: 'Scarlett'
}

function sayName(user) {
    console.log(this.name, user.name);
}

 var _sayName = angular.bind(user1, sayName, user2);

_sayName();
```

效果就是打印出了 Jax Scarlett

## angular.identity

该函数也很简单，就是返回这个函数接收到的第一个参数例子也用官方的例子好了

```
function getResult(fn, input) {
    return (fn || angular.identity)(input);
};

getResult(function(n) { return n * 2; }, 21);   // returns 42
getResult(null, 21);                            // returns 21
getResult(undefined, 21);                       // returns 21
```

## angular.isUndefined

判断传入的参数是否为undefined

```
console.log(angular.isUndefined(undefined)); // true
console.log(angular.isUndefined(null)); // false
```

## angular.isDefined

判断传入进来的参数是否不是undefined

```
console.log(angular.isDefined(undefined)); // false
console.log(angular.isDefined(null)); // true
```

## angular.isString

判断传入进来的参数是否为字符串

```
console.log(angular.isString('123')); // true
console.log(angular.isString(123)); // false

```

## angular.isNumber

判断传进来的参数是否为number类型

```
console.log(angular.isNumber('123')); // false
console.log(angular.isNumber(123)); // true
```

## angular.isFunction

判断传递进来的参数是否为一个函数

```
console.log(angular.isFunction(fn)); // true
console.log(angular.isFunction(fn())); // false
```

## angular.isObject

判断传递进来的参数是否为对象(null 除外)

```
console.log(angular.isObject({})); // true
console.log(angular.isObject(null)); // false
console.log(angular.isObject(123)); // false

```

## angular.isArray

就是Array.isArray判断传入进来的参数是否为数组

```
console.log(angular.isArray([])); // true
console.log(angular.isArray(null)); // false
```

## angular.isElement

判断传递进来的参数是否为一个DOM节点(被jquery扩展过的也可)

```
var body = angular.element(document.getElementsByTagName('body')[0]);

console.log(angular.isElement(body)); // true
```

## angular.isDate

判断传递进来的对象是否为Date类型

```
console.log(angular.isDate(new Date())); // true
```

## angular.lowercase

将一个字符串转换为小写

## angular.upercase

将一个字符串转换为小写

```
console.log(angular.lowercase('ABCD')); // abcd
console.log(angular.uppercase('abcd')); // ABCD
```

## angular.version

这是一个属性，返回angular的版本